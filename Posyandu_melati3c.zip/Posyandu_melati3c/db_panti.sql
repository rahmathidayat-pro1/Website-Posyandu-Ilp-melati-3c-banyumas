-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Des 2025 pada 13.54
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_panti`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `narasi_balita`
--

CREATE TABLE `narasi_balita` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `narasi_balita`
--

INSERT INTO `narasi_balita` (`id`, `judul`, `isi`, `created_at`) VALUES
(1, 'Data Balita Usia 0–5 Tahun', '<section class=\"section-balita\" style=\"padding: 30px 20px; background: #f7f9ff; border-radius: 8px; margin-top: 20px;\">\r\n        <h2 style=\"font-weight: 700; color: #1b4db9; margin-bottom: 10px; font-size: 24px;\">\r\n            Data Balita Usia 0–5 Tahun\r\n        </h2>\r\n\r\n        <p style=\"font-size: 16px; line-height: 1.7; text-align: justify; color: #333;\">\r\n            Posyandu ILP Melati 3C Banyumas saat ini melayani \r\n            <strong>34 balita usia 0–5 tahun</strong> yang tersebar di wilayah binaan.\r\n            Dari jumlah tersebut, terdapat <strong>20 balita perempuan</strong> dan \r\n            <strong>14 balita laki-laki</strong>. \r\n\r\n            Seluruh balita secara rutin mengikuti kegiatan pemantauan pertumbuhan,\r\n            penimbangan berat badan, pengukuran tinggi badan, serta pemeriksaan\r\n            kesehatan dasar setiap bulan. Kegiatan ini menjadi bagian penting\r\n            dalam memastikan tumbuh kembang balita tetap optimal, mencegah risiko\r\n            stunting, serta mendukung kesehatan keluarga di lingkungan masyarakat.\r\n\r\n            Dengan data balita yang terpantau dengan baik, Posyandu memiliki dasar\r\n            yang kuat untuk merancang program kesehatan yang lebih tepat sasaran.\r\n        </p>\r\n    </section>', '2025-11-24 06:33:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_alumni`
--

CREATE TABLE `tbl_alumni` (
  `id_alumni` int(11) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `email` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` varchar(12) NOT NULL,
  `tahun_masuk` year(4) NOT NULL,
  `tahun_keluar` year(4) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_donasi`
--

CREATE TABLE `tbl_donasi` (
  `id_donasi` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `tanggal_donasi` date NOT NULL,
  `id_jenis_donasi` int(11) NOT NULL,
  `nominal` float NOT NULL,
  `foto` text NOT NULL,
  `keterangan` varchar(500) NOT NULL,
  `status` enum('verifikasi','ditolak','proses','-') NOT NULL,
  `keterangan_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_donasi`
--

INSERT INTO `tbl_donasi` (`id_donasi`, `username`, `tanggal_donasi`, `id_jenis_donasi`, `nominal`, `foto`, `keterangan`, `status`, `keterangan_status`) VALUES
(11, 'donatur', '2022-06-16', 1, 20000000, '1655375950267.PNG', 'bismillah', 'verifikasi', ''),
(12, 'donatur', '2022-06-16', 1, 10000000, '1655375984889.PNG', 'bismillah 2', 'verifikasi', 'dana digunakan untuk bla bla bla'),
(13, 'kamelia', '2022-06-18', 1, 200000000, '1655554068580.PNG', 'bismillah', '-', '-'),
(14, 'kamelia', '2022-06-18', 1, 12300000000000, '1655554185121.PNG', 'bismillah', '-', '-');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_donatur`
--

CREATE TABLE `tbl_donatur` (
  `id_donatur` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_telepon` varchar(50) NOT NULL,
  `kota` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_donatur`
--

INSERT INTO `tbl_donatur` (`id_donatur`, `username`, `nama`, `alamat`, `email`, `no_telepon`, `kota`) VALUES
(12, 'donatur', 'gidion adi saputra', 'tg pinang', 'gidionadisaputra@gmail.com', '085664761579', 'tanjungpinang'),
(13, 'kamelia', 'kamelia', 'tg pinang', 'kamelamel70@gmail.com', '0000000', 'tanjungpinang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_jenis_donasi`
--

CREATE TABLE `tbl_jenis_donasi` (
  `id` int(11) NOT NULL,
  `jenis_donasi` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_jenis_donasi`
--

INSERT INTO `tbl_jenis_donasi` (`id`, `jenis_donasi`) VALUES
(1, 'Donasi Melalui Rekening');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kategorimedia`
--

CREATE TABLE `tbl_kategorimedia` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kunjungan`
--

CREATE TABLE `tbl_kunjungan` (
  `id_kunjungan` int(11) NOT NULL,
  `nama_pengunjung` varchar(50) NOT NULL,
  `tanggal_kunjungan` date NOT NULL,
  `alamat_pengunjung` varchar(50) NOT NULL,
  `no_telepon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_kunjungan`
--

INSERT INTO `tbl_kunjungan` (`id_kunjungan`, `nama_pengunjung`, `tanggal_kunjungan`, `alamat_pengunjung`, `no_telepon`) VALUES
(1, 'gidion', '2022-03-01', 'pinang hijau', '085664761579');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_media`
--

CREATE TABLE `tbl_media` (
  `id` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `judul_media` varchar(200) NOT NULL,
  `isi_media` varchar(1000) NOT NULL,
  `gambar` varchar(500) NOT NULL,
  `tanggal_publish` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pengeluaran`
--

CREATE TABLE `tbl_pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` float NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_pengeluaran`
--

INSERT INTO `tbl_pengeluaran` (`id_pengeluaran`, `tanggal`, `nominal`, `keterangan`) VALUES
(1, '2022-06-16', 300000, 'beli beras');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_role`
--

CREATE TABLE `tbl_role` (
  `id` int(11) NOT NULL,
  `nama_role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_role`
--

INSERT INTO `tbl_role` (`id`, `nama_role`) VALUES
(1, 'Admin'),
(2, 'Ketua Panti\r\n'),
(3, 'Donatur');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_settingprofil`
--

CREATE TABLE `tbl_settingprofil` (
  `id` int(11) NOT NULL,
  `nama_web` varchar(50) NOT NULL,
  `detail_profil` text NOT NULL,
  `logo` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` int(16) NOT NULL,
  `fax` int(16) NOT NULL,
  `facebook` varchar(50) NOT NULL,
  `twitter` varchar(50) NOT NULL,
  `instagram` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_settingprofil`
--

INSERT INTO `tbl_settingprofil` (`id`, `nama_web`, `detail_profil`, `logo`, `alamat`, `email`, `telepon`, `fax`, `facebook`, `twitter`, `instagram`) VALUES
(4, 'LKSA Panti Asuhan Muhammadiyah Tanjungpinang', 'Panti Asuhan Muhammadiyah Kota Tanjungpinang beralamat di   Jl. Kamboja no 22 Tanjungpinang telp: 0771. 24600 dengan akta pendirian Muhammadiyah sebagai badan hukum dengan nomor : A / 2 – 975 / 1986 dan MKKM Pusat	:   No .IV.A / 1.c/022 / 1999. Panti asuhan muhmmadiyah berada di Kelurahan Kamboja No 22 Kecamatan  Tanjungpinang Barat Kota Tanjungpinang Propinsi Kepulauan Riau. Lembaga Kesejahteraan Sosial Anak Muhammadiyah Tanjungpinang bediri sekitar Tahun 1950-an. Hal ini didasarkan pada izin operasional  dari Kementrian Agama Sumatra Tengah di Bukit Tinggi Sumatera Barat. Pada mulanya jumlah anak asuh pertama kali sebanyak 14 (empat belas) orang. Pengurus pertama yaitu Bapak Umar Awaludin. Seiring berjalannya waktu maka sampai tahun 1995 Lembaga Kesejahteraan Sosial Anak Muhammadiyah mengembangkan sayap dalam peningkatan pelayanan. Pengurus menambah bagunan panti asuhan yang bersifat parmanen dengan alamat di Kauman Muhammadiyah Km 8 Tanjungpinang Timur dengan luas lahan 20.000 M2 sebagai bangunan asrama putra.  Pendirian LKSA Muhammadiyah adalah merujuk  pada Badan Hukum Pimpinan Pusat Muhammadiyah Nomor : A/2 – 975 / 1986 dan tercatat sebagai Amal Usaha Perserikatan Muhammadiyah dengan Nomor : IV.A / 1.c/022 / 1999 yang menyatakan bahwa Panti Asuhan Muhammadiyah di Jl. Kamboja No 22 Tanjungpinang adalah amal Usaha Persyarikatan Muhammadiyah yang berada dalam pembinaan Pimpinan Pusat Muhammadiyah pada Majelis Pembinaan Kesejahteraan Sosial dan Pengembangan Masyarakat. Selanjutnya Panti Asuhan Muhammadiyah terdaftar pada Dinas Tenaga Kerja dan Kesejahteraan sosial Kota Tanjungpinang dengan Nomor : DTKKS /XI / 2007 / 449.', '1655372393599.png', 'Komplek Muhammadiyah, Jl. Kauman, Jl. RH. Fisabilillah no. 70 KM. 8 atas, Batu IX, Kec. Tanjungpinang Tim., Kota Tanjung Pinang, Kepulauan Riau 29125', 'lksamuhi@gmail.com', 2147483647, 123, 'https://www.facebook.com/lksamuhammadiyah.tanjungp', 'https://twitter.com/LKSAmuhtpi/', 'https://www.instagram.com/lksa_muhtpi/');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `role_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama_user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `role_id`, `email`, `nama_user`) VALUES
(1, 'admin', '$2y$10$CpQuDBbV17FiPm6gX8Y4guSe0ulPSQGcwjgOusQXPubuy.dB9WOj.', 1, 'gidionadisaputra@gmail.com', 'Gidion Adi Saputra'),
(7, 'ketua panti', '$2y$10$Ji9aFAvH4iqfeJtsWSbee.4nOJ6rrUwyV./MzS9hX.gpb5af9YFbG', 2, 'KP@gmail.com', 'Akhmad Nurkholis'),
(8, 'donatur', '$2y$10$jGiqq1hRJpz8TnO/9ElHD.l53l40uo0KEUwJGJxPlWUPTivo6LIeW', 3, 'gidionadisaputra@gmail.com', 'gidion adi saputra'),
(9, 'kamelia', '$2y$10$mGOEAc9i1Vw1KsRMCZwaC.TA6OSj760X43pl2HV7K8rSBL9qzUJyO', 3, 'kamelamel70@gmail.com', 'kamelia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_fasilitas`
--

CREATE TABLE `tb_fasilitas` (
  `id` int(11) NOT NULL,
  `fasilitas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_fasilitas`
--

INSERT INTO `tb_fasilitas` (`id`, `fasilitas`) VALUES
(3, '<div style=\"font-family: \'Poppins\', Arial, sans-serif; line-height: 1.8; color: #333; text-align: justify;\">\r\n\r\n    <h2 style=\"font-size: 28px; font-weight: 700; color: #0d47a1; margin-bottom: 12px; text-align:left;\">\r\n        Fasilitas Posyandu\r\n    </h2>\r\n\r\n    <p style=\"margin-bottom: 18px;\">\r\n        Posyandu dilengkapi dengan berbagai fasilitas pendukung untuk menunjang kegiatan pelayanan \r\n        kesehatan bagi balita, ibu hamil, lansia, dan masyarakat umum. Berikut adalah fasilitas yang \r\n         tersedia di Posyandu:\r\n    </p>\r\n\r\n    <ul style=\"padding-left: 20px; margin-top: 10px;\">\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Meja pendaftaran</strong> untuk pencatatan identitas dan kehadiran peserta Posyandu.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Alat timbang balita (dacin atau digital)</strong> untuk mengukur berat badan anak secara rutin.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Alat pengukur tinggi badan / panjang badan balita</strong> sebagai bagian dari pemantauan tumbuh kembang.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Kartu Menuju Sehat (KMS)</strong> atau buku pemantauan kesehatan sebagai media pencatatan status gizi.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Meja pelayanan imunisasi</strong> yang digunakan oleh tenaga kesehatan saat memberikan vaksin.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Peralatan kesehatan dasar</strong> seperti tensimeter, stetoskop, termometer, dan perlengkapan P3K.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Ruang konsultasi</strong> untuk penyuluhan gizi, pola asuh, serta konsultasi kesehatan dengan kader atau bidan.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Ruang tunggu</strong> yang nyaman bagi ibu dan anak selama pelayanan berlangsung.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Alat peraga edukasi</strong> seperti poster kesehatan, media penyuluhan, dan leaflet informasi.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Meja pemberian makanan tambahan (PMT)</strong> untuk kegiatan pemberian makanan bergizi kepada balita.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Buku administrasi Posyandu</strong> untuk mencatat seluruh kegiatan dan laporan bulanan.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            <strong>Ruang laktasi sederhana</strong> sebagai tempat ibu menyusui secara nyaman dan aman.\r\n        </li>\r\n\r\n    </ul>\r\n\r\n</div>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kepengurusan`
--

CREATE TABLE `tb_kepengurusan` (
  `id` int(11) NOT NULL,
  `kepengurusan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_kepengurusan`
--

INSERT INTO `tb_kepengurusan` (`id`, `kepengurusan`) VALUES
(3, '<table class=\"table table-bordered\"><tbody><tr><td><span style=\"font-size: 14px;\">NO.</span></td><td><span style=\"font-size: 14px;\">NAMA</span></td><td><span style=\"font-size: 14px;\">JABATAN</span></td></tr><tr><td><span style=\"font-size: 14px;\">1.</span></td><td><font face=\"Arial, sans-serif\"><span style=\"font-size: 14px;\">Drs. H. Mukhtar Sujadi</span></font></td><td><span style=\"font-size: 14px;\">Ketua Pimpinan Derah Muhammadiyah Tanjungpinang</span></td></tr><tr><td><span style=\"font-size: 14px;\">2.</span></td><td><span style=\"font-size: 14px;\">Akhmad Nurkholis</span></td><td><span style=\"font-size: 14px;\">Pengasuh Panti Asuhan Muhammadiyah Tanjungpinang</span></td></tr><tr><td><span style=\"font-size: 14px;\">3.</span></td><td><span style=\"font-size: 14px;\">Sudharmawan, S.E, Ak</span></td><td><span style=\"font-size: 14px;\">Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</span></td></tr><tr><td><span style=\"font-size: 14px;\">4.</span></td><td><span style=\"font-size: 14px;\">Dr. A. Suradji Muhammad, M.Si</span></td><td><span style=\"font-size: 14px;\">Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</span><br></td></tr><tr><td><span style=\"font-size: 14px;\">5.</span></td><td><span style=\"font-size: 14px;\">Annash Fajjri Nugroho, S.AP</span></td><td><span style=\"font-size: 14px;\">Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</span><br></td></tr></tbody></table>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kontak_kami`
--

CREATE TABLE `tb_kontak_kami` (
  `id` int(11) NOT NULL,
  `kontak_kami` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_log`
--

CREATE TABLE `tb_log` (
  `id` int(11) NOT NULL,
  `aktivitas` text NOT NULL,
  `oleh` text NOT NULL,
  `pada` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_log`
--

INSERT INTO `tb_log` (`id`, `aktivitas`, `oleh`, `pada`) VALUES
(1, 'admin telah login ke sistem', 'admin', '2022-05-05 09:38:19'),
(2, 'admin menambahkan data peran sad', 'admin', '2022-05-05 10:06:47'),
(3, 'admin mengubah peran sads', 'admin', '2022-05-05 10:07:17'),
(4, 'admin menghapus data peran sads', 'admin', '2022-05-05 10:07:20'),
(5, 'admin menambahkan data user Cypherlabs', 'admin', '2022-05-05 10:21:45'),
(6, 'admin mengubah user ', 'admin', '2022-05-05 10:21:57'),
(7, 'admin mengubah user ', 'admin', '2022-05-05 10:22:12'),
(8, 'admin menghapus data user ', 'admin', '2022-05-05 10:22:16'),
(9, 'admin menambahkan data jenid donasi Donasi Melalui Rekening', 'admin', '2022-05-05 10:38:05'),
(10, 'admin menambahkan data jenid donasi Donasi Menggunakan Bahan Pokok', 'admin', '2022-05-05 10:38:19'),
(11, 'admin mengubah jenis donasi Donasi Menggunakan Bahan Pokoks', 'admin', '2022-05-05 10:38:23'),
(12, 'admin menghapus data jenis donasi ', 'admin', '2022-05-05 10:38:26'),
(13, 'admin menghapus data jenis donasi ', 'admin', '2022-05-05 10:38:58'),
(14, 'admin menambahkan data jenid donasi asdads', 'admin', '2022-05-05 10:39:13'),
(15, 'admin menghapus data jenis donasi asdads', 'admin', '2022-05-05 10:39:17'),
(16, 'admin menambahkan data nama kategori media buku', 'admin', '2022-05-05 10:48:52'),
(17, 'admin mengubah kategori media bukus', 'admin', '2022-05-05 10:48:59'),
(18, 'admin mengubah kategori media buku', 'admin', '2022-05-05 10:49:07'),
(19, 'admin menghapus data kategori media buku', 'admin', '2022-05-05 10:49:10'),
(20, 'admin menambahkan data visi misi <p>Visi</p><p><p>asdas</p><p><br></p><p>Misi</p><p>asdads</p><p><br></p><p><img style=\"width: 797.2px;\" src=\"http://localhost:8080/panti_asuhan/upload/visi_misi/logo_zakat_baznas_-_Copy.png\"><br></p><p>                                                    </p></p>', 'admin', '2022-05-05 11:13:56'),
(21, 'admin mengubah visi misi <p>Visi</p><p></p><p>asdas</p><p><br></p><p>Misi</p><p>asdads</p><p><br></p><p><br></p><p>                                                    </p><p></p>', 'admin', '2022-05-05 11:14:09'),
(22, 'admin menghapus data visi misi <p>Visi</p><p></p><p>asdas</p><p><br></p><p>Misi</p><p>asdads</p><p><br></p><p><br></p><p>                                                    </p><p></p>', 'admin', '2022-05-05 11:14:14'),
(23, 'admin menambahkan data visi misi <p>asdadsds</p><p><img src=\"http://localhost:8080/panti_asuhan/upload/kontak_kami/rekening_zakatt.png\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-05 11:19:39'),
(24, 'admin mengubah visi misi <p>asdadsds</p><p><br></p>', 'admin', '2022-05-05 11:19:45'),
(25, 'admin menghapus data visi misi <p>asdadsds</p><p><br></p>', 'admin', '2022-05-05 11:19:49'),
(26, 'admin menambahkan data visi misi <p>Struktur Organisasi</p><p><br></p><p><img src=\"http://localhost:8080/panti_asuhan/upload/struktur_organisasi/Logo_Zakat_Basnaz_6.png\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-05 11:23:59'),
(27, 'admin mengubah visi misi <p>Struktur Organisasi</p><p><br></p><p><br></p>', 'admin', '2022-05-05 11:24:05'),
(28, 'admin menghapus data visi misi <p>Struktur Organisasi</p><p><br></p><p><br></p>', 'admin', '2022-05-05 11:24:08'),
(29, 'admin menambahkan data visi misi <div><br></div><div><div class=\"col-md-8\" style=\"min-height: 1px; float: left; width: 800px; color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"row\"><div class=\"callback-warp cbw-h5\"><div class=\"col-md-12\" style=\"min-height: 1px; float: left; width: 800px;\"><div class=\"group-title-btn\" style=\"display: inline-block; width: 770px; position: relative;\"><div class=\"title-block\" style=\"display: inline-block; width: auto; float: left;\"><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\">PANDUAN PENDAFTARAN</h3><span class=\"bottom-title\" style=\"clear: both; display: block; width: 70px; height: 4px; background: rgb(255, 182, 0);\"></span></div><div class=\"customNavigation\" style=\"position: absolute; top: 35.8px; right: 0px;\">&nbsp;<a class=\"btn-3 btn-3-next next-step\" style=\"background: rgb(10, 44, 78); color: rgb(255, 255, 255); width: 28px; height: 34px; transition: all 0.5s ease-in-out 0s; line-height: 34px; text-align: center; font-size: 18px; display: inline-block; position: relative; margin-left: 4px;\"><span class=\"fa fa-angle-right\" style=\"font-weight: normal; font-stretch: normal; font-family: FontAwesome; font-size: inherit;\"></span></a></div></div><div class=\"plan-warp-h5\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"><div class=\"owl-wrapper\" style=\"position: relative; transform: translate3d(0px, 0px, 0px); backface-visibility: hidden; width: 1544px; left: 0px;\"><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Menaati Peraturan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Test</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengisi Formulir</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengisi Formulir yang telah di sediakan.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengajukan Permohonan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri persyaratan yang ada.</p></div></div></div></div></div></div></div></div></div></div><div class=\"row\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"services-2-detail-warp\"><div class=\"col-md-6\" style=\"min-height: 1px; float: left; width: 615px;\"><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\"><br></h3><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\"><br></h3><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\"><br></h3><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\"><span style=\"font-family: inherit;\">Syarat - syarat Diterima</span><br></h3><span class=\"bottom-title\" style=\"clear: both; display: block; width: 70px; height: 4px; background: rgb(255, 182, 0);\"></span><br><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">Setiap anak asuh PAKYM Surakarta harus memiliki persyaratan yang sudah ditentukan</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\"><b style=\"font-weight: bold;\">Syarat :</b></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">1. Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri:</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; a. Surat Keterngan dari Keleruhan yang menyatakan betul-betul anak yatim/yatim piatu dan tidak mampu.<strong style=\"font-weight: bold;\"></strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; b. Surat Kematian ayah bagi anak yatim atau surat kematian ayah dan ibu bagi yatim piatu</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; c. Surat keterangan dari Pimpinan Muhammadiyah setempat yang isinya sesuai dengan point a</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; d. Umur 6 s/d 12 thaun dibuktikan dengan surat kelahiran/akta kelahiran</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; e. Pas Foto 3x4 sebanyak 3 lembar</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; f. Surat keterangan dokter yang menyatakan tidak cacat mental dan tubuh</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g. Surat keterangan yang menyatakan masih atauu pernah sekolah ( dari asal sekolah)</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; h. Fotocopy KK</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">2. Mengisi Formulir yang telah di sediakan</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">3. Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">4. Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p></div></div></div></div></div><div><div class=\"plan-warp-h5\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"></div></div></div></div>', 'admin', '2022-05-05 11:33:20'),
(30, 'admin mengubah visi misi <div>asdadsadsadssda</div>', 'admin', '2022-05-05 11:34:09'),
(31, 'admin menghapus data visi misi <div>asdadsadsadssda</div>', 'admin', '2022-05-05 11:34:12'),
(32, 'admin menambahkan data Media Berita 1', 'admin', '2022-05-05 12:12:49'),
(33, 'admin menambahkan data Media Berita 1', 'admin', '2022-05-05 12:13:20'),
(34, 'admin mengubah media Berita 1', 'admin', '2022-05-05 12:16:37'),
(35, 'admin mengubah media Berita 1s', 'admin', '2022-05-05 12:16:49'),
(36, 'admin mengubah media Berita 1s', 'admin', '2022-05-05 12:17:00'),
(37, 'admin menghapus data media ', 'admin', '2022-05-05 12:17:05'),
(38, 'admin menambahkan data profil Panti Asuhan Muhammadiyah Tanjungpinang', 'admin', '2022-05-05 12:42:22'),
(39, 'admin mengubah profil Panti Asuhan Muhammadiyah Tanjungpinang1', 'admin', '2022-05-05 12:42:42'),
(40, 'admin mengubah profil Panti Asuhan Muhammadiyah Tanjungpinang1', 'admin', '2022-05-05 12:42:51'),
(41, 'admin menghapus data profil ', 'admin', '2022-05-05 12:42:58'),
(42, 'admin telah login ke sistem', 'admin', '2022-05-08 12:21:13'),
(43, 'admin menambahkan data anak asuhsadads', 'admin', '2022-05-08 12:55:23'),
(44, 'admin mengubah data anak asuh sadads', 'admin', '2022-05-08 12:58:00'),
(45, 'admin mengubah data anak asuh sadads', 'admin', '2022-05-08 12:58:07'),
(46, 'admin mengubah data anak asuh sadads', 'admin', '2022-05-08 12:58:21'),
(47, 'admin mengubah data anak asuh sadads', 'admin', '2022-05-08 12:59:26'),
(48, 'admin menghapus data anak asuh sadads', 'admin', '2022-05-08 12:59:31'),
(49, 'admin mengubah data alumni sdfsdf', 'admin', '2022-05-08 02:09:23'),
(50, 'admin menambahkan data pengeluaranBeli Papan Tulis', 'admin', '2022-05-08 02:34:28'),
(51, 'admin mengubah data pengeluaran Beli Papan Tuliss', 'admin', '2022-05-08 02:35:37'),
(52, 'admin menghapus data pengeluaran Beli Papan Tuliss', 'admin', '2022-05-08 02:35:44'),
(53, 'admin telah login ke sistem', 'admin', '2022-05-08 05:09:29'),
(54, 'admin menambahkan data visi misi <span style=\"color: rgb(114, 114, 114); font-size: 13px; background-color: rgb(255, 255, 255);\">Penanaman iman dan takwa, Akhlaqul Karimah, Pelayanan Sosial dan Pendidikan Anak Asuh.</span>', 'admin', '2022-05-08 05:11:33'),
(55, 'admin mengubah visi misi <p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\"><strong style=\"font-weight: bold;\">Visi:</strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">Penanaman iman dan takwa, Akhlaqul Karimah, Pelayanan Sosial dan Pendidikan Anak Asuh.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\"><strong style=\"font-weight: bold;\">Misi:</strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Memberikan Pendidikan agama Islam yang sesuai dengan misi persyarikatan Muhammadiyah</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Memberi bekal Pendidikan formal, keterampilan, kewirauhaan dan kecakapan hidup (life skill) kepada anak asuh.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Memberi Pendidikan pengkaderan secara konsisten agar dapat bertanggungjawab terhadap dirinya, lingkungan masyarakat, persyarikatan Muhammadiyah, agama, nusa dan bangsa.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Perlindungan pada anak asuh terhadap gangguan-gangguan fisik, mental dan social</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Pembinaan terhadap anak asuh dalam mencapai tujuan usaha-usaha kesejahteraan social.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Pengembangan dan peningkatan krearifitas, kecerdasan, dan keahlian anak asuh.</p>', 'admin', '2022-05-08 05:11:45'),
(56, 'admin menambahkan data visi misi <ul class=\"icon-link-list-icon\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; list-style: none; line-height: 28px; font-size: 13px;\"><li style=\"display: inline-block; position: relative; width: 270px; padding-left: 25px;\"><font color=\"#000000\" style=\"background-color: rgb(255, 255, 255);\">Jl. Slamet Riyadi No.441, Pajang, Laweyan, Kota Surakarta kode pos 57146</font></li></ul>', 'admin', '2022-05-08 05:12:25'),
(57, 'admin menambahkan data visi misi <p><img src=\"http://localhost:8080/panti_asuhan/upload/struktur_organisasi/struktur_organisasi.jpeg\" style=\"width: 800px;\">                                                    </p>', 'admin', '2022-05-08 05:13:40'),
(58, 'admin menambahkan data visi misi <div class=\"col-md-8\" style=\"min-height: 1px; float: left; width: 800px; color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"row\"><div class=\"callback-warp cbw-h5\"><div class=\"col-md-12\" style=\"min-height: 1px; float: left; width: 800px;\"><div class=\"plan-warp-h5\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"><div class=\"owl-wrapper\" style=\"position: relative; transform: translate3d(0px, 0px, 0px); backface-visibility: hidden; width: 1544px; left: 0px;\"><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Menaati Peraturan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Test</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengisi Formulir</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengisi Formulir yang telah di sediakan.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengajukan Permohonan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri persyaratan yang ada.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div></div></div></div></div></div></div></div></div><div class=\"row\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"services-2-detail-warp\"><div class=\"col-md-6\" style=\"min-height: 1px; float: left; width: 615px;\"><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><br></div><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><br></div><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><br></div><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><br></div><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><br></div><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><br></div></div></div></div><div class=\"row\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"services-2-detail-warp\"><div class=\"col-md-6\" style=\"min-height: 1px; float: left; width: 615px;\"><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\">Syarat - syarat Diterima</h3><span class=\"bottom-title\" style=\"clear: both; display: block; width: 70px; height: 4px; background: rgb(255, 182, 0);\"></span><br><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">Setiap anak asuh PAKYM Surakarta harus memiliki persyaratan yang sudah ditentukan</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\"><b style=\"font-weight: bold;\">Syarat :</b></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">1. Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri:</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; a. Surat Keterngan dari Keleruhan yang menyatakan betul-betul anak yatim/yatim piatu dan tidak mampu.<strong style=\"font-weight: bold;\"></strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; b. Surat Kematian ayah bagi anak yatim atau surat kematian ayah dan ibu bagi yatim piatu</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; c. Surat keterangan dari Pimpinan Muhammadiyah setempat yang isinya sesuai dengan point a</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; d. Umur 6 s/d 12 thaun dibuktikan dengan surat kelahiran/akta kelahiran</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; e. Pas Foto 3x4 sebanyak 3 lembar</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; f. Surat keterangan dokter yang menyatakan tidak cacat mental dan tubuh</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g. Surat keterangan yang menyatakan masih atauu pernah sekolah ( dari asal sekolah)</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; h. Fotocopy KK</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">2. Mengisi Formulir yang telah di sediakan</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">3. Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">4. Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p></div></div></div></div>', 'admin', '2022-05-08 05:14:47'),
(59, 'admin mengubah visi misi <div class=\"row\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"services-2-detail-warp\"><div class=\"col-md-6\" style=\"min-height: 1px; float: left; width: 615px;\"><span style=\"color: rgb(34, 34, 34); font-family: inherit; font-size: 24px; font-weight: 600;\">Syarat - syarat Diterima</span><br></div></div></div><div class=\"row\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"services-2-detail-warp\"><div class=\"col-md-6\" style=\"min-height: 1px; float: left; width: 615px;\"><div class=\"title-block title-contact\" style=\"display: inline-block; width: 585px; margin-bottom: 60px;\"><span class=\"bottom-title\" style=\"clear: both; display: block; width: 70px; height: 4px; background: rgb(255, 182, 0);\"></span><br><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">Setiap anak asuh PAKYM Surakarta harus memiliki persyaratan yang sudah ditentukan</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\"><b style=\"font-weight: bold;\">Syarat :</b></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">1. Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri:</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; a. Surat Keterngan dari Keleruhan yang menyatakan betul-betul anak yatim/yatim piatu dan tidak mampu.<strong style=\"font-weight: bold;\"></strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; b. Surat Kematian ayah bagi anak yatim atau surat kematian ayah dan ibu bagi yatim piatu</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; c. Surat keterangan dari Pimpinan Muhammadiyah setempat yang isinya sesuai dengan point a</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; d. Umur 6 s/d 12 thaun dibuktikan dengan surat kelahiran/akta kelahiran</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp; e. Pas Foto 3x4 sebanyak 3 lembar</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; f. Surat keterangan dokter yang menyatakan tidak cacat mental dan tubuh</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g. Surat keterangan yang menyatakan masih atauu pernah sekolah ( dari asal sekolah)</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; h. Fotocopy KK</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">2. Mengisi Formulir yang telah di sediakan</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">3. Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px;\">4. Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p></div></div></div></div>', 'admin', '2022-05-08 05:15:12'),
(60, 'admin menambahkan data profil Panti Asuhan Muhammadiyah Tanjungpinang', 'admin', '2022-05-08 05:17:13'),
(61, 'admin menambahkan data Media IDUL FITRI 1443 H', 'admin', '2022-05-08 05:18:13'),
(62, 'admin telah login ke sistem', 'admin', '2022-05-08 05:21:23'),
(63, 'admin menambahkan data Media Rafting Sungai Elo', 'admin', '2022-05-08 05:21:57'),
(64, 'admin telah login ke sistem', 'admin', '2022-05-08 05:54:50'),
(65, 'admin mengubah visi misi <div class=\"row\" style=\"\"><div class=\"services-2-detail-warp\" style=\"\"><br></div><div class=\"services-2-detail-warp\" style=\"\"><div class=\"group-title-btn\" style=\"display: inline-block; width: 770px; position: relative; color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"title-block\" style=\"display: inline-block; width: auto; float: left;\"><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\">PANDUAN PENDAFTARAN</h3><span class=\"bottom-title\" style=\"clear: both; display: block; width: 70px; height: 4px; background: rgb(255, 182, 0);\"><br></span></div></div><span style=\"color: rgb(114, 114, 114); font-size: 13px;\"></span><div class=\"plan-warp-h5\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"><div class=\"owl-wrapper\" style=\"position: relative; transform: translate3d(0px, 0px, 0px); backface-visibility: hidden; width: 1544px; left: 0px;\"><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Menaati Peraturan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Test</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengisi Formulir</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengisi Formulir yang telah di sediakan.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengajukan Permohonan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri persyaratan yang ada.</p></div></div></div></div></div></div></div></div>', 'admin', '2022-05-08 05:56:32'),
(66, 'admin telah login ke sistem', 'admin', '2022-05-08 05:56:53'),
(67, 'admin mengubah visi misi <div class=\"row\" style=\"\"><div class=\"services-2-detail-warp\" style=\"\"><br></div><div class=\"services-2-detail-warp\" style=\"\"><div class=\"group-title-btn\" style=\"display: inline-block; width: 770px; position: relative; color: rgb(114, 114, 114); font-size: 13px;\"><div class=\"title-block\" style=\"display: inline-block; width: auto; float: left;\"><h3 style=\"line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 24px;\">&nbsp; PANDUAN PENDAFTARAN</h3><span class=\"bottom-title\" style=\"clear: both; display: block; width: 70px; height: 4px; background: rgb(255, 182, 0);\"><br></span></div></div><span style=\"color: rgb(114, 114, 114); font-size: 13px;\"></span><div class=\"plan-warp-h5\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"><div class=\"owl-wrapper\" style=\"position: relative; transform: translate3d(0px, 0px, 0px); backface-visibility: hidden; width: 1544px; left: 0px;\"><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Menaati Peraturan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Sanggup mentaati peraturan dan tata tertib panti baik untuk anak asuh mupun keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Test</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengikuti tes/ wawancara khususnya keluarga</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengisi Formulir</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengisi Formulir yang telah di sediakan.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p></div></div><div class=\"owl-item\" style=\"float: left; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); width: 193px;\"><div class=\"item-plan-step\" style=\"text-align: center; border-top: 2px dotted rgb(221, 221, 221);\"><div class=\"step\" style=\"width: 70px; height: 70px; line-height: 70px; font-size: 24px; color: rgb(255, 255, 255); border-radius: 50%; margin: -35px auto 35px; background: rgb(255, 182, 0);\"><img src=\"https://pakymsurakarta.com/images/icon/sign-out.png\" width=\"30\" height=\"30\" style=\"border: 0px;\"></div><h4 style=\"font-weight: 500; line-height: 1.4; color: rgb(34, 34, 34); margin-bottom: 10px; font-size: 18px; padding: 0px 15px;\">Mengajukan Permohonan</h4><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\"></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px 15px;\">Mengajukan Permohonan kepada Pimpinan Panti Asuhan dilampiri persyaratan yang ada.</p></div></div></div></div></div></div></div></div>', 'admin', '2022-05-08 05:57:18'),
(68, 'admin mengubah visi misi <div class=\"row\" style=\"\"><div class=\"services-2-detail-warp\" style=\"\"><img src=\"http://localhost:8080/panti_asuhan/upload/alur_pendaftaran/Screenshot_2022-05-08_175759.png\" style=\"width: 800px;\"><br></div><div class=\"services-2-detail-warp\" style=\"\"><div class=\"plan-warp-h5\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"></div></div></div></div></div>', 'admin', '2022-05-08 05:58:14'),
(69, 'admin telah login ke sistem', 'admin', '2022-05-08 06:11:47'),
(70, 'admin menambahkan data kunjunganasd', 'admin', '2022-05-08 06:28:55'),
(71, 'admin mengubah data kunjungan asdsad', 'admin', '2022-05-08 06:29:05'),
(72, 'admin menghapus data kunjungan asdsad', 'admin', '2022-05-08 06:29:09'),
(73, 'admin telah login ke sistem', 'admin', '2022-05-08 09:06:13'),
(74, 'admin menghapus data alumni Robby Kurniawan', 'admin', '2022-05-08 09:07:19'),
(75, 'admin menghapus data alumni Robby Kurniawan', 'admin', '2022-05-08 09:07:24'),
(76, 'admin telah login ke sistem', 'admin', '2022-05-08 09:07:58'),
(77, 'admin telah login ke sistem', 'admin', '2022-05-08 09:09:31'),
(78, 'admin menghapus data alumni Robby Kurniawan', 'admin', '2022-05-08 09:09:41'),
(79, 'robby23241 telah login ke sistem', 'robby23241', '2022-05-08 09:27:53'),
(80, 'robby23241 menambahkan data donasi Donasi Pertama', 'robby23241', '2022-05-08 10:11:23'),
(81, 'robby23241 menambahkan data donasi Donasi Pertama', 'robby23241', '2022-05-08 10:11:28'),
(82, 'robby23241 menambahkan data donasi as', 'robby23241', '2022-05-08 10:12:52'),
(83, 'robby23241 menambahkan data donasi as', 'robby23241', '2022-05-08 10:14:00'),
(84, 'robby23241 menambahkan data donasi as', 'robby23241', '2022-05-08 10:16:23'),
(85, 'robby23241 menambahkan data donasi as', 'robby23241', '2022-05-08 10:16:51'),
(86, 'robby23241 mengubah media as2', 'robby23241', '2022-05-08 10:17:17'),
(87, 'robby23241 mengubah media as2', 'robby23241', '2022-05-08 10:18:13'),
(88, 'admin telah login ke sistem', 'admin', '2022-05-08 10:19:51'),
(89, 'admin menghapus data pemasukan as2', 'admin', '2022-05-08 10:34:57'),
(90, 'robby23241 telah login ke sistem', 'robby23241', '2022-05-08 10:35:19'),
(91, 'admin telah login ke sistem', 'admin', '2022-05-08 10:35:30'),
(92, 'admin menghapus data pemasukan as2', 'admin', '2022-05-08 10:35:51'),
(93, 'robby23241 telah login ke sistem', 'robby23241', '2022-05-08 10:36:06'),
(94, 'admin telah login ke sistem', 'admin', '2022-05-08 10:36:37'),
(95, 'robby23241 telah login ke sistem', 'robby23241', '2022-05-08 10:47:25'),
(96, 'robby23241 menambahkan data donasi Coba', 'robby23241', '2022-05-08 10:47:45'),
(97, 'admin telah login ke sistem', 'admin', '2022-05-08 10:47:57'),
(98, 'admin menghapus data pemasukan Coba', 'admin', '2022-05-08 10:48:14'),
(99, 'admin telah login ke sistem', 'admin', '2022-05-09 10:46:09'),
(100, 'admin menambahkan data user dion123', 'admin', '2022-05-09 10:46:50'),
(101, 'dion123 telah login ke sistem', 'dion123', '2022-05-09 10:46:55'),
(102, 'admin telah login ke sistem', 'admin', '2022-05-10 09:14:32'),
(103, 'admin menambahkan data visi misi <p>eweddwe</p><p><img src=\"http://localhost:8080/panti_asuhan/upload/kepengurusan/IMG_8581.jpg\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-10 10:01:01'),
(104, 'admin mengubah visi misi <p>eweddwe</p><p><br></p>', 'admin', '2022-05-10 10:01:08'),
(105, 'admin menghapus data visi misi <p>eweddwe</p><p><br></p>', 'admin', '2022-05-10 10:01:13'),
(106, 'admin menambahkan data fasilitas <p>asddsad</p><p><img src=\"http://localhost:8080/panti_asuhan/upload/fasilitas/capture.png\" style=\"width: 793px;\"><br></p>', 'admin', '2022-05-10 10:04:13'),
(107, 'admin mengubah fasilitas <p>asddsad</p><p><br></p>', 'admin', '2022-05-10 10:04:19'),
(108, 'admin menghapus data fasilitas <p>asddsad</p><p><br></p>', 'admin', '2022-05-10 10:04:22'),
(109, 'admin menambahkan data tujuan <p>saads</p><p><img src=\"http://localhost:8080/panti_asuhan/upload/tujuan/IMG_8581.jpg\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-10 10:06:22'),
(110, 'admin mengubah tujuan <p>saads</p><p><br></p>', 'admin', '2022-05-10 10:06:28'),
(111, 'admin menghapus data tujuan <p>saads</p><p><br></p>', 'admin', '2022-05-10 10:06:32'),
(112, 'admin menambahkan data program_kerja <p>asdads</p><p><img src=\"http://localhost:8080/panti_asuhan/upload/program_kerja/capture.png\" style=\"width: 793px;\"><br></p>', 'admin', '2022-05-10 10:09:09'),
(113, 'admin mengubah program_kerja <p>asdads</p><p><br></p>', 'admin', '2022-05-10 10:09:14'),
(114, 'admin menghapus data program_kerja <p>asdads</p><p><br></p>', 'admin', '2022-05-10 10:09:17'),
(115, 'admin telah login ke sistem', 'admin', '2022-05-11 11:38:52'),
(116, 'admin menambahkan data fasilitas asddsadsa', 'admin', '2022-05-11 11:39:04'),
(117, 'admin menambahkan data tujuan asddsa', 'admin', '2022-05-11 11:39:10'),
(118, 'admin menambahkan data Kepengurusan asddsa', 'admin', '2022-05-11 11:39:15'),
(119, 'admin menambahkan data program_kerja asdd', 'admin', '2022-05-11 11:39:21'),
(120, 'admin telah login ke sistem', 'admin', '2022-05-11 11:40:02'),
(121, 'admin telah login ke sistem', 'admin', '2022-05-11 11:58:05'),
(122, 'admin menambahkan data slider <p><img src=\"http://localhost:8080/panti_asuhan/upload/slider/resize_11949gedungpay.jpg\" style=\"width: 800px;\">                                                    </p>', 'admin', '2022-05-11 11:59:46'),
(123, 'admin menambahkan data slider <p>                                                    <img src=\"http://localhost:8080/panti_asuhan/upload/slider/img_0337.jpg\" style=\"width: 800px;\"></p>', 'admin', '2022-05-11 12:00:21'),
(124, 'admin menambahkan data slider <p>                                                    <img src=\"http://localhost:8080/panti_asuhan/upload/slider/WhatsApp-Image-2021-02-17-at-16_25_25.jpeg\" style=\"width: 800px;\"></p>', 'admin', '2022-05-11 12:00:40'),
(125, 'admin telah login ke sistem', 'admin', '2022-05-11 12:07:28'),
(126, 'admin menghapus data slider <p>                                                    <img src=\"http://localhost:8080/panti_asuhan/upload/slider/WhatsApp-Image-2021-02-17-at-16_25_25.jpeg\" style=\"width: 800px;\"></p>', 'admin', '2022-05-11 12:08:05'),
(127, 'admin menghapus data slider <p><img src=\"http://localhost:8080/panti_asuhan/upload/slider/resize_11949gedungpay.jpg\" style=\"width: 800px;\">                                                    </p>', 'admin', '2022-05-11 12:08:10'),
(128, 'admin menghapus data slider <p>                                                    <img src=\"http://localhost:8080/panti_asuhan/upload/slider/img_0337.jpg\" style=\"width: 800px;\"></p>', 'admin', '2022-05-11 12:08:13'),
(129, 'admin menambahkan data slider ', 'admin', '2022-05-11 12:12:48'),
(130, 'admin menambahkan data slider ', 'admin', '2022-05-11 12:13:12'),
(131, 'admin menambahkan data slider ', 'admin', '2022-05-11 12:13:25'),
(132, 'admin menambahkan data slider ', 'admin', '2022-05-11 12:13:33'),
(133, 'admin menambahkan data slider ', 'admin', '2022-05-11 12:13:48'),
(134, 'admin menambahkan data slider ', 'admin', '2022-05-11 12:14:32'),
(135, 'admin menghapus data slider 1652245968614.jpg', 'admin', '2022-05-11 12:15:17'),
(136, 'admin menghapus data slider 1652245992290.jpg', 'admin', '2022-05-11 12:15:20'),
(137, 'admin menghapus data slider 1652246005876.jpeg', 'admin', '2022-05-11 12:15:23'),
(138, 'admin mengubah slider ', 'admin', '2022-05-11 12:15:31'),
(139, 'admin telah login ke sistem', 'admin', '2022-05-11 01:39:10'),
(140, 'admin telah login ke sistem', 'admin', '2022-05-13 02:17:08'),
(141, 'admin menambahkan data panduan_donasi <p>asddasads</p><p><img src=\"http://localhost:8080/panti_asuhan/upload/panduan_donasi/Screenshot_2022-05-08_175759.png\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-13 02:21:25'),
(142, 'admin mengubah panduan_donasi <p><br></p><p><img src=\"http://localhost:8080/panti_asuhan/upload/panduan_donasi/Screenshot_2022-05-08_175759.png\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-13 02:21:29'),
(143, 'admin menghapus data panduan_donasi <p><br></p><p><img src=\"http://localhost:8080/panti_asuhan/upload/panduan_donasi/Screenshot_2022-05-08_175759.png\" style=\"width: 800px;\"><br></p>', 'admin', '2022-05-13 02:21:34'),
(144, 'admin menambahkan data panduan_donasi <p>                                                    <img src=\"http://localhost:8080/panti_asuhan/upload/panduan_donasi/Screenshot_2022-05-08_1757591.png\" style=\"width: 800px;\"></p>', 'admin', '2022-05-13 02:21:42'),
(145, 'admin telah login ke sistem', 'admin', '2022-06-16 04:25:56'),
(146, 'admin telah login ke sistem', 'admin', '2022-06-16 04:30:07'),
(147, 'admin mengubah slider ', 'admin', '2022-06-16 04:32:13'),
(148, 'admin mengubah slider ', 'admin', '2022-06-16 04:32:41'),
(149, 'admin mengubah slider ', 'admin', '2022-06-16 04:32:53'),
(150, 'admin menghapus data profil ', 'admin', '2022-06-16 04:33:28'),
(151, 'admin menambahkan data profil LKSA Panti Asuhan Muhammadiyah Tanjungpinang', 'admin', '2022-06-16 04:39:53');
INSERT INTO `tb_log` (`id`, `aktivitas`, `oleh`, `pada`) VALUES
(152, 'admin menghapus data visi misi <p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\"><strong style=\"font-weight: bold;\">Visi:</strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">Penanaman iman dan takwa, Akhlaqul Karimah, Pelayanan Sosial dan Pendidikan Anak Asuh.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\"><strong style=\"font-weight: bold;\">Misi:</strong></p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Memberikan Pendidikan agama Islam yang sesuai dengan misi persyarikatan Muhammadiyah</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Memberi bekal Pendidikan formal, keterampilan, kewirauhaan dan kecakapan hidup (life skill) kepada anak asuh.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Memberi Pendidikan pengkaderan secara konsisten agar dapat bertanggungjawab terhadap dirinya, lingkungan masyarakat, persyarikatan Muhammadiyah, agama, nusa dan bangsa.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Perlindungan pada anak asuh terhadap gangguan-gangguan fisik, mental dan social</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Pembinaan terhadap anak asuh dalam mencapai tujuan usaha-usaha kesejahteraan social.</p><p style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; color: rgb(114, 114, 114); font-size: 13px;\">- Pengembangan dan peningkatan krearifitas, kecerdasan, dan keahlian anak asuh.</p>', 'admin', '2022-06-16 04:41:26'),
(153, 'admin menghapus data visi misi <p><img src=\"http://localhost:8080/panti_asuhan/upload/struktur_organisasi/struktur_organisasi.jpeg\" style=\"width: 800px;\">                                                    </p>', 'admin', '2022-06-16 04:44:32'),
(154, 'admin menghapus data fasilitas asddsadsa', 'admin', '2022-06-16 04:44:39'),
(155, 'admin menghapus data tujuan asddsa', 'admin', '2022-06-16 04:44:45'),
(156, 'admin menghapus data program_kerja asdd', 'admin', '2022-06-16 04:44:51'),
(157, 'admin menghapus data Kepengurusan asddsa', 'admin', '2022-06-16 04:44:56'),
(158, 'admin menghapus data media ', 'admin', '2022-06-16 04:45:13'),
(159, 'admin menghapus data media ', 'admin', '2022-06-16 04:45:19'),
(160, 'admin menghapus data media ', 'admin', '2022-06-16 04:45:22'),
(161, 'admin telah login ke sistem', 'admin', '2022-06-16 04:46:03'),
(162, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:22'),
(163, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:26'),
(164, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:34'),
(165, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:35'),
(166, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:35'),
(167, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:40'),
(168, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:42'),
(169, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:48'),
(170, 'admin menghapus data media ', 'admin', '2022-06-16 04:46:49'),
(171, 'admin menghapus data visi misi <div class=\"row\" style=\"\"><div class=\"services-2-detail-warp\" style=\"\"><img src=\"http://localhost:8080/panti_asuhan/upload/alur_pendaftaran/Screenshot_2022-05-08_175759.png\" style=\"width: 800px;\"><br></div><div class=\"services-2-detail-warp\" style=\"\"><div class=\"plan-warp-h5\" style=\"color: rgb(114, 114, 114); font-size: 13px;\"><div id=\"plan-h5\" class=\"owl-plan-h5 owl-carousel owl-theme\" style=\"position: relative; width: 770px; opacity: 1;\"><div class=\"owl-wrapper-outer\" style=\"overflow: hidden; position: relative; width: 770px; padding-top: 80px;\"></div></div></div></div></div>', 'admin', '2022-06-16 04:46:58'),
(172, 'admin menghapus data panduan_donasi <p>                                                    <img src=\"http://localhost:8080/panti_asuhan/upload/panduan_donasi/Screenshot_2022-05-08_1757591.png\" style=\"width: 800px;\"></p>', 'admin', '2022-06-16 04:47:06'),
(173, 'admin menghapus data visi misi <ul class=\"icon-link-list-icon\" style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; list-style: none; line-height: 28px; font-size: 13px;\"><li style=\"display: inline-block; position: relative; width: 270px; padding-left: 25px;\"><font color=\"#000000\" style=\"background-color: rgb(255, 255, 255);\">Jl. Slamet Riyadi No.441, Pajang, Laweyan, Kota Surakarta kode pos 57146</font></li></ul>', 'admin', '2022-06-16 04:47:13'),
(174, 'admin menambahkan data visi misi <p class=\"MsoNormal\" style=\"background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-US\"><font color=\"#000000\">VISI :<o:p></o:p></font></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><font color=\"#000000\"><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:\r\n&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:\r\nEN-ID;mso-fareast-language:EN-ID\">Menjadikan&nbsp;</span><span lang=\"IN\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;\"><span lang=\"EN-ID\" style=\"\">Panti\r\n<font color=\"#000000\">Asuhan </font>dan Pondok Pesantren <font color=\"#000000\">Muhammadiyah</font></span></span><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:&quot;Times New Roman&quot;;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-ID;mso-fareast-language:\r\nEN-ID\"> Tanjungpinang sebagai lembaga Sosial, Pendidikan dan Dakwah yang\r\nmencetak kader-kader Muhammadiyah yang terampil, mandiri dan berakhlak mulia</span><span lang=\"IN\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:\r\n&quot;Times New Roman&quot;;mso-fareast-language:IN\">”.</span><span style=\"mso-bidi-font-size:\r\n12.0pt;line-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:\r\nEN-US;mso-fareast-language:IN\"><o:p></o:p></span></font></p>\r\n\r\n<p class=\"MsoNormal\" style=\"background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-US;mso-fareast-language:IN\"><font color=\"#000000\">&nbsp;</font></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-US;mso-fareast-language:IN\"><font color=\"#000000\">MISI :<o:p></o:p></font></span></p>\r\n\r\n<p class=\"MsoNormal\" align=\"left\" style=\"margin-left: 0.5in; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><font color=\"#000000\"><span lang=\"EN-ID\" style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;line-height:150%;\r\nmso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">1.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:\r\n&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:\r\nEN-ID;mso-fareast-language:EN-ID\">Memfasilitasi pendidikan formal minimal SMA/MA\r\nkepada anak asuh<o:p></o:p></span></font></p>\r\n\r\n<p class=\"MsoNormal\" align=\"left\" style=\"margin-left: 0.5in; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><font color=\"#000000\"><span lang=\"EN-ID\" style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;line-height:150%;\r\nmso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">2.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:\r\n&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:\r\nEN-ID;mso-fareast-language:EN-ID\">Memberikan pendidikan Agama Islam sesuai Al\r\nQur’an dan As Sunnah Shohihah&nbsp; (Aqidah,Akhlak,Ibadah dan Muamalah).<o:p></o:p></span></font></p>\r\n\r\n<p class=\"MsoNormal\" align=\"left\" style=\"margin-left: 0.5in; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><font color=\"#000000\"><span lang=\"EN-ID\" style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;line-height:150%;\r\nmso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">3.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"IN\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:\r\n&quot;Times New Roman&quot;;mso-fareast-language:IN\">Membekali anak asuh dengan IMTAQ,\r\nIPTEK, keterampilan agar menjadi anak yang sholeh/ah dan mandiri.</span><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:\r\n&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:\r\nEN-ID;mso-fareast-language:EN-ID\"><o:p></o:p></span></font></p>\r\n\r\n<p class=\"MsoNormal\" align=\"left\" style=\"margin-left: 0.5in; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><font color=\"#000000\"><span lang=\"EN-ID\" style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;line-height:150%;\r\nmso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">4.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"IN\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:\r\n&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-fareast-language:\r\nIN\">Memberikan pe</span><span style=\"mso-bidi-font-size:12.0pt;line-height:\r\n150%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-US;mso-fareast-language:IN\">ngasuhan</span><span lang=\"IN\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-fareast-font-family:&quot;Times New Roman&quot;;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;;mso-fareast-language:IN\"> kepada anak\r\nasuh sesuai dengan hak-hak anak.</span><span lang=\"EN-ID\" style=\"mso-bidi-font-size:\r\n12.0pt;line-height:150%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:\r\n&quot;Times New Roman&quot;;mso-ansi-language:EN-ID;mso-fareast-language:EN-ID\"><o:p></o:p></span></font></p>\r\n\r\n<p class=\"MsoNormal\" style=\"background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:150%;mso-bidi-font-family:\r\n&quot;Times New Roman&quot;;mso-ansi-language:EN-ID\"><font color=\"#000000\">&nbsp;</font></span></p>\r\n\r\n<p class=\"MsoNormal\"><span style=\"mso-bidi-font-size:12.0pt;line-height:150%;\r\nmso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US\"><font color=\"#000000\">&nbsp;</font></span></p>', 'admin', '2022-06-16 04:54:06'),
(175, 'admin menambahkan data visi misi <p class=\"MsoNormal\" style=\"text-align: center; \"><img src=\"http://localhost/panti/upload/struktur_organisasi/hk.PNG\" style=\"width: 50%;\"><br></p>', 'admin', '2022-06-16 05:02:31'),
(176, 'admin menambahkan data fasilitas <p>1. Masjid</p><p>2. Asrama</p><p>3. Lapangan</p><p>4. Gedung Sekolah</p><p>5. Perlengkapan Olahraga</p><p>6. Kantor</p><p>7. Bus Angkutan</p><p>8. Kamar Tidur</p><p>9. Kamar Mandi dan WC</p><p>10. Dapur</p>', 'admin', '2022-06-16 05:05:28'),
(177, 'admin menambahkan data tujuan <p class=\"MsoListParagraph\" style=\"text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:\r\n150%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">Terselenggaranya kegiatan\r\nsosial, pendidikan dan dakwah berbasis panti asuhan dan Pondok Pesantren yang\r\nunggul serta tangguh dalam membentuk kader ulama, pemimpin, pendidik, serta\r\nmanusia karya yang mandiri dan produktif yang senantiasa mendukung pencapaian\r\ntujuan Muhammadiyah&nbsp; yakni terwujudnya masyarakat Islam yang\r\nsebenar-benarnya.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align: justify; \"><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;\r\nline-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-ID\">&nbsp;</span></p>', 'admin', '2022-06-16 05:06:46'),
(178, 'admin menambahkan data program_kerja <p class=\"MsoListParagraphCxSpFirst\" style=\"text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><b><span lang=\"EN-ID\">1.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></b><!--[endif]--><b><span lang=\"EN-ID\">PROGRAM JANGKA PENDEK</span></b><b><span lang=\"EN-ID\"><o:p></o:p></span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">a.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Memenuhi\r\nKebutuhan Dasar penerima manfaat<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">b.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Meningkatkan\r\npelayanan Pendidikan dan Kesejahteraan penerima manfaat<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">c.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Menjalin\r\nKemitraan dengan Masyarakat,Lembaga Pemerintah/Non Pemerintah<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">d.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Menggali\r\nsumber-sumber : Informasi, Dana, Baik itu dari Lingkup Muhammadiyah, maupun\r\nLembaga Pemerintah,Swasta dan Dunia Usaha.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><b><span lang=\"EN-ID\">2.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></b><!--[endif]--><b><span lang=\"EN-ID\">PROGRAM JANGKA MENENGAH</span></b><b><span lang=\"EN-ID\"><o:p></o:p></span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><b><span lang=\"EN-ID\">&nbsp;</span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">a.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Membangun\r\natau melengkapi fasilitas pendukung asrama dan kesejahteraan anak asuh dengan\r\nmemprioritaskan ;<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 63.8pt; text-indent: -14.15pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\" style=\"font-family:\r\n&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:&quot;Arial Narrow&quot;;mso-bidi-font-family:\r\n&quot;Arial Narrow&quot;;mso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">-<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span><!--[endif]--><span lang=\"EN-ID\">Pengadaan fasilitas, merehab atau melengkapi\r\nsarana dan bangunan sesuai kebutuhan dan prioritas.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 63.8pt; text-indent: -14.15pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\" style=\"font-family:\r\n&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:&quot;Arial Narrow&quot;;mso-bidi-font-family:\r\n&quot;Arial Narrow&quot;;mso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">-<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span><!--[endif]--><span lang=\"EN-ID\">Menganalisis kelayakan dan melengkapi sarana\r\ntempat tinggal anak asuh, fasilitas belajar dan sarana pendukung pendidikan\r\nserta keterampilan.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">b.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Membangun\r\nsistem pendidikan karakter anak asuh dengan membentuk tim kurikulum, evaluasi\r\ndan standar kompetensi bekerja sama dengan Dikdasmen Muhammadiyah, Lembaga\r\nPendidikan pemerintah dan swasta.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\">c.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Membentuk\r\nUEP (Usaha Ekonomi Produktif) melalui potensi SDA dan SDM Panti untuk mendukung\r\npemasukan dana panti secara mandiri serta kaya manfaat bagi persyarikatan dan\r\nlingkungan masyarakat. <o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\">&nbsp;<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpFirst\" style=\"text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><b><span lang=\"EN-ID\">3.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></b><!--[endif]--><b><span lang=\"EN-ID\">PROGRAM JANGKA PANJANG</span></b><b><span lang=\"EN-ID\"><o:p></o:p></span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\" style=\"font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:\r\n&quot;Arial Narrow&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;;mso-ansi-language:EN-ID;\r\nmso-fareast-language:EN-ID\">a.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Membangun\r\nunit-unit usaha/life skill sebagai media pelatihan bagi penerima manfaat untuk\r\nberwirausaha/menciptakan lapangan kerja agar dapat mandiri<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align: justify; margin-left: 49.65pt; text-indent: -14.2pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><!--[if !supportLists]--><span lang=\"EN-ID\" style=\"font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:\r\n&quot;Arial Narrow&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;;mso-ansi-language:EN-ID;\r\nmso-fareast-language:EN-ID\">b.<span style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span lang=\"EN-ID\">Menjadikan\r\nLKSA Panti Asuhan sebagai “<i>basic social connector</i>” antara Persyarikatan\r\nMuhammadiyah dengan Lingkungan Masyarakat melalui kegiatan pendidikan,\r\nkeagamaan serta kegiatan sosial.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align: justify; \"><span lang=\"EN-ID\" style=\"font-size:14.0pt;mso-bidi-font-size:\r\n12.0pt;line-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:\r\nEN-ID\">&nbsp;</span></p>', 'admin', '2022-06-16 05:15:47'),
(179, 'admin menambahkan data Kepengurusan <table class=\"table table-bordered\"><tbody><tr><td>NO.</td><td>NAMA</td><td>JABATAN</td></tr><tr><td>1.</td><td><font face=\"Arial, sans-serif\"><span style=\"font-size: 14.6667px;\">Drs. H. Mukhtar Sujadi</span></font></td><td>Ketua Pimpinan Derah Muhammadiyah Tanjungpinang</td></tr><tr><td>2.</td><td>Akhmad Nurkholis</td><td>Pengasuh Panti Asuhan Muhammadiyah Tanjungpinang</td></tr><tr><td>3.</td><td>Sudharmawan, S.E, Ak</td><td>Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</td></tr><tr><td>4.</td><td>Dr. A. Suradji Muhammad, M.Si</td><td>Pengurus Panti Asuhan Muhammadiyah Tanjungpinang<br></td></tr><tr><td>5.</td><td>Annash Fajjri Nugroho, S.AP</td><td>Pengurus Panti Asuhan Muhammadiyah Tanjungpinang<br></td></tr></tbody></table>', 'admin', '2022-06-16 05:25:49'),
(180, 'admin mengubah Kepengurusan <table class=\"table table-bordered\"><tbody><tr><td><span style=\"font-size: 14px;\">NO.</span></td><td><span style=\"font-size: 14px;\">NAMA</span></td><td><span style=\"font-size: 14px;\">JABATAN</span></td></tr><tr><td><span style=\"font-size: 14px;\">1.</span></td><td><font face=\"Arial, sans-serif\"><span style=\"font-size: 14px;\">Drs. H. Mukhtar Sujadi</span></font></td><td><span style=\"font-size: 14px;\">Ketua Pimpinan Derah Muhammadiyah Tanjungpinang</span></td></tr><tr><td><span style=\"font-size: 14px;\">2.</span></td><td><span style=\"font-size: 14px;\">Akhmad Nurkholis</span></td><td><span style=\"font-size: 14px;\">Pengasuh Panti Asuhan Muhammadiyah Tanjungpinang</span></td></tr><tr><td><span style=\"font-size: 14px;\">3.</span></td><td><span style=\"font-size: 14px;\">Sudharmawan, S.E, Ak</span></td><td><span style=\"font-size: 14px;\">Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</span></td></tr><tr><td><span style=\"font-size: 14px;\">4.</span></td><td><span style=\"font-size: 14px;\">Dr. A. Suradji Muhammad, M.Si</span></td><td><span style=\"font-size: 14px;\">Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</span><br></td></tr><tr><td><span style=\"font-size: 14px;\">5.</span></td><td><span style=\"font-size: 14px;\">Annash Fajjri Nugroho, S.AP</span></td><td><span style=\"font-size: 14px;\">Pengurus Panti Asuhan Muhammadiyah Tanjungpinang</span><br></td></tr></tbody></table>', 'admin', '2022-06-16 05:26:48'),
(181, 'admin telah login ke sistem', 'admin', '2022-06-16 05:30:38'),
(182, 'admin mengubah user ', 'admin', '2022-06-16 05:32:24'),
(183, 'admin telah login ke sistem', 'admin', '2022-06-16 05:32:56'),
(184, 'Ketua Panti telah login ke sistem', 'Ketua Panti', '2022-06-16 05:33:21'),
(185, 'admin telah login ke sistem', 'admin', '2022-06-16 05:33:39'),
(186, 'admin mengubah user ', 'admin', '2022-06-16 05:34:08'),
(187, 'donatur telah login ke sistem', 'donatur', '2022-06-16 05:38:24'),
(188, 'donatur menambahkan data donasi bismillah', 'donatur', '2022-06-16 05:39:10'),
(189, 'donatur menambahkan data donasi bismillah 2', 'donatur', '2022-06-16 05:39:44'),
(190, 'admin telah login ke sistem', 'admin', '2022-06-16 05:39:53'),
(191, 'admin menghapus data pemasukan bismillah 2', 'admin', '2022-06-16 05:40:16'),
(192, 'admin mengubah data pengeluaran beli beras', 'admin', '2022-06-16 05:41:04'),
(193, 'donatur telah login ke sistem', 'donatur', '2022-06-17 06:32:07'),
(194, 'ketua panti telah login ke sistem', 'ketua panti', '2022-06-17 07:02:01'),
(195, 'admin telah login ke sistem', 'admin', '2022-06-17 08:06:26'),
(196, 'admin telah login ke sistem', 'admin', '2022-06-18 03:09:21'),
(197, 'admin mengubah peran Donatur', 'admin', '2022-06-18 03:29:17'),
(198, 'admin menghapus data pemasukan bismillah', 'admin', '2022-06-18 04:41:57'),
(199, 'admin telah login ke sistem', 'admin', '2022-06-18 06:03:33'),
(200, 'donatur telah login ke sistem', 'donatur', '2022-06-18 06:10:31'),
(201, 'kamelia telah login ke sistem', 'kamelia', '2022-06-18 07:07:09'),
(202, 'kamelia menambahkan data donasi bismillah', 'kamelia', '2022-06-18 07:07:48'),
(203, 'kamelia menambahkan data donasi bismillah', 'kamelia', '2022-06-18 07:09:45'),
(204, 'admin telah login ke sistem', 'admin', '2022-06-19 02:10:16'),
(205, 'donatur telah login ke sistem', 'donatur', '2022-06-19 05:53:53'),
(206, 'admin telah login ke sistem', 'admin', '2022-06-20 03:32:51'),
(207, 'admin telah login ke sistem', 'admin', '2022-06-20 05:35:32'),
(208, 'admin telah login ke sistem', 'admin', '2022-06-21 11:38:03'),
(209, 'admin telah login ke sistem', 'admin', '2022-06-22 03:13:31'),
(210, 'admin telah login ke sistem', 'admin', '2022-06-22 10:41:15'),
(211, 'admin telah login ke sistem', 'admin', '2022-06-23 04:19:48'),
(212, 'admin menambahkan data Media xxm', 'admin', '2022-06-23 04:23:15'),
(213, 'admin menambahkan data Media hgjkhj', 'admin', '2022-06-23 04:27:37'),
(214, 'donatur telah login ke sistem', 'donatur', '2022-06-24 03:30:28'),
(215, 'ketua panti telah login ke sistem', 'ketua panti', '2022-06-24 03:33:00'),
(216, 'admin telah login ke sistem', 'admin', '2022-06-24 03:34:02'),
(217, 'admin telah login ke sistem', 'admin', '2022-06-26 02:02:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_panduan_donasi`
--

CREATE TABLE `tb_panduan_donasi` (
  `id` int(11) NOT NULL,
  `panduan_donasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pendaftaran_anak_asuh`
--

CREATE TABLE `tb_pendaftaran_anak_asuh` (
  `id` int(11) NOT NULL,
  `alur_pendaftaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_program_kerja`
--

CREATE TABLE `tb_program_kerja` (
  `id` int(11) NOT NULL,
  `program_kerja` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_program_kerja`
--

INSERT INTO `tb_program_kerja` (`id`, `program_kerja`) VALUES
(3, '<div style=\"font-family: \'Poppins\', Arial, sans-serif; line-height: 1.8; color: #333; text-align: justify;\">\r\n\r\n    <h2 style=\"font-size: 28px; font-weight: 700; color: #0d47a1; margin-bottom: 10px; text-align:left;\">\r\n        Program Kerja Posyandu\r\n    </h2>\r\n\r\n    <p style=\"margin-bottom: 18px;\">\r\n        Program kerja Posyandu disusun sebagai upaya untuk meningkatkan pelayanan kesehatan dasar, \r\n        pemberdayaan masyarakat, serta mendukung tumbuh kembang balita, remaja, ibu hamil, dan lansia.\r\n        Berikut adalah susunan program kerja Posyandu secara umum:\r\n    </p>\r\n\r\n    <ol style=\"padding-left: 20px; margin-top: 15px;\">\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Menyelenggarakan kegiatan penimbangan balita secara rutin setiap bulan sebagai \r\n            upaya pemantauan pertumbuhan dan perkembangan anak.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Melaksanakan imunisasi dasar lengkap bekerja sama dengan tenaga kesehatan Puskesmas.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Memberikan penyuluhan kesehatan kepada masyarakat mengenai gizi, kebersihan, \r\n            pola asuh, dan pencegahan penyakit.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Melakukan pemantauan kesehatan ibu hamil, ibu menyusui, dan lansia secara terjadwal.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Menyediakan pelayanan konsultasi gizi dan tumbuh kembang melalui kader Posyandu dan bidan desa.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Mengadakan kegiatan pemberdayaan masyarakat seperti kelas ibu hamil, kelas balita, \r\n            dan pelatihan kader kesehatan.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Melaksanakan program Perilaku Hidup Bersih dan Sehat (PHBS) sebagai upaya pembangunan \r\n            kesehatan berbasis masyarakat.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Menjalin koordinasi dengan Puskesmas, pemerintah desa, serta lembaga masyarakat \r\n            dalam upaya peningkatan layanan kesehatan.\r\n        </li>\r\n\r\n        <li style=\"margin-bottom: 10px;\">\r\n            Mengadakan pendataan dan pelaporan kegiatan Posyandu secara berkala sebagai bahan evaluasi \r\n            dan peningkatan layanan.\r\n        </li>\r\n\r\n    </ol>\r\n\r\n</div>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_slider`
--

CREATE TABLE `tb_slider` (
  `id` int(11) NOT NULL,
  `slider` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_slider`
--

INSERT INTO `tb_slider` (`id`, `slider`) VALUES
(7, 'banner 01.jpg'),
(8, 'banner 2.jpg'),
(9, 'banner 3.jpg'),
(10, 'banner 4.jpg'),
(11, 'banner 5.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_struktur_organisasi`
--

CREATE TABLE `tb_struktur_organisasi` (
  `id` int(11) NOT NULL,
  `struktur_organisasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_struktur_organisasi`
--

INSERT INTO `tb_struktur_organisasi` (`id`, `struktur_organisasi`) VALUES
(3, '<p class=\"MsoNormal\" style=\"text-align: center; \"><img src=\"http://localhost/Posyandu_melati3c/upload/struktur_organisasi/struktur organisasii.PNG\" style=\"width:45%;\"><br></p>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tujuan`
--

CREATE TABLE `tb_tujuan` (
  `id` int(11) NOT NULL,
  `tujuan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_tujuan`
--

INSERT INTO `tb_tujuan` (`id`, `tujuan`) VALUES
(3, '<p class=\"MsoListParagraph\" style=\"text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;line-height:\r\n150%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;;\r\nmso-ansi-language:EN-ID;mso-fareast-language:EN-ID\">Terselenggaranya kegiatan\r\nsosial, pendidikan dan dakwah berbasis panti asuhan dan Pondok Pesantren yang\r\nunggul serta tangguh dalam membentuk kader ulama, pemimpin, pendidik, serta\r\nmanusia karya yang mandiri dan produktif yang senantiasa mendukung pencapaian\r\ntujuan Muhammadiyah&nbsp; yakni terwujudnya masyarakat Islam yang\r\nsebenar-benarnya.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align: justify; \"><span lang=\"EN-ID\" style=\"mso-bidi-font-size:12.0pt;\r\nline-height:150%;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-ID\">&nbsp;</span></p>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_visi_misi`
--

CREATE TABLE `tb_visi_misi` (
  `id` int(11) NOT NULL,
  `visi_misi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_visi_misi`
--

INSERT INTO `tb_visi_misi` (`id`, `visi_misi`) VALUES
(3, '<div class=\"section\">\r\n    <h2 style=\"font-weight: 700; font-size: 28px; margin-bottom: 10px;\">Visi</h2>\r\n    <p style=\"margin-bottom: 25px; font-size: 17px; line-height: 1.7;\">\r\n        Mewujudkan masyarakat yang sehat, mandiri, dan berdaya melalui pelayanan kesehatan dasar yang terpadu,\r\n        berkesinambungan, serta mudah diakses oleh seluruh lapisan masyarakat.\r\n    </p>\r\n\r\n    <h2 style=\"font-weight: 700; font-size: 28px; margin-bottom: 10px;\">Misi</h2>\r\n    <ol style=\"padding-left: 20px; font-size: 17px; line-height: 1.8;\">\r\n        <li>Memberikan pelayanan kesehatan dasar bagi ibu hamil, balita, remaja, dan lansia secara teratur dan berkesinambungan.</li>\r\n        <li>Meningkatkan status gizi masyarakat, terutama bayi dan balita, melalui pemantauan tumbuh kembang dan edukasi gizi.</li>\r\n        <li>Mendorong kemandirian masyarakat dalam upaya kesehatan melalui pemberdayaan kader Posyandu.</li>\r\n        <li>Mengoptimalkan kegiatan promotif dan preventif seperti imunisasi, penyuluhan kesehatan, dan pencegahan penyakit.</li>\r\n        <li>Memfasilitasi koordinasi antara masyarakat dengan fasilitas pelayanan kesehatan seperti Puskesmas dan bidan desa.</li>\r\n        <li>Mewujudkan lingkungan yang sehat melalui penerapan Perilaku Hidup Bersih dan Sehat (PHBS).</li>\r\n        <li>Meningkatkan partisipasi aktif keluarga dan masyarakat dalam kegiatan Posyandu.</li>\r\n    </ol>\r\n</div>\r\n');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `narasi_balita`
--
ALTER TABLE `narasi_balita`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  ADD PRIMARY KEY (`id_alumni`);

--
-- Indeks untuk tabel `tbl_donasi`
--
ALTER TABLE `tbl_donasi`
  ADD PRIMARY KEY (`id_donasi`),
  ADD KEY `id_jenis_donasi` (`id_jenis_donasi`),
  ADD KEY `id_donatur` (`username`);

--
-- Indeks untuk tabel `tbl_donatur`
--
ALTER TABLE `tbl_donatur`
  ADD PRIMARY KEY (`id_donatur`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `tbl_jenis_donasi`
--
ALTER TABLE `tbl_jenis_donasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_kategorimedia`
--
ALTER TABLE `tbl_kategorimedia`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_kunjungan`
--
ALTER TABLE `tbl_kunjungan`
  ADD PRIMARY KEY (`id_kunjungan`),
  ADD KEY `id_mapel` (`alamat_pengunjung`),
  ADD KEY `id_kelas_santri` (`tanggal_kunjungan`),
  ADD KEY `id_guru` (`nama_pengunjung`);

--
-- Indeks untuk tabel `tbl_media`
--
ALTER TABLE `tbl_media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `tbl_pengeluaran`
--
ALTER TABLE `tbl_pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indeks untuk tabel `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_settingprofil`
--
ALTER TABLE `tbl_settingprofil`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `id_level` (`role_id`);

--
-- Indeks untuk tabel `tb_fasilitas`
--
ALTER TABLE `tb_fasilitas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_kepengurusan`
--
ALTER TABLE `tb_kepengurusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_kontak_kami`
--
ALTER TABLE `tb_kontak_kami`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_log`
--
ALTER TABLE `tb_log`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_panduan_donasi`
--
ALTER TABLE `tb_panduan_donasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_pendaftaran_anak_asuh`
--
ALTER TABLE `tb_pendaftaran_anak_asuh`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_program_kerja`
--
ALTER TABLE `tb_program_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_slider`
--
ALTER TABLE `tb_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_struktur_organisasi`
--
ALTER TABLE `tb_struktur_organisasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_tujuan`
--
ALTER TABLE `tb_tujuan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_visi_misi`
--
ALTER TABLE `tb_visi_misi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `narasi_balita`
--
ALTER TABLE `narasi_balita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  MODIFY `id_alumni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tbl_donasi`
--
ALTER TABLE `tbl_donasi`
  MODIFY `id_donasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `tbl_donatur`
--
ALTER TABLE `tbl_donatur`
  MODIFY `id_donatur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `tbl_jenis_donasi`
--
ALTER TABLE `tbl_jenis_donasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbl_kategorimedia`
--
ALTER TABLE `tbl_kategorimedia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbl_kunjungan`
--
ALTER TABLE `tbl_kunjungan`
  MODIFY `id_kunjungan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbl_media`
--
ALTER TABLE `tbl_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT untuk tabel `tbl_pengeluaran`
--
ALTER TABLE `tbl_pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tbl_settingprofil`
--
ALTER TABLE `tbl_settingprofil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tb_fasilitas`
--
ALTER TABLE `tb_fasilitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_kepengurusan`
--
ALTER TABLE `tb_kepengurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_kontak_kami`
--
ALTER TABLE `tb_kontak_kami`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_log`
--
ALTER TABLE `tb_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=218;

--
-- AUTO_INCREMENT untuk tabel `tb_panduan_donasi`
--
ALTER TABLE `tb_panduan_donasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_pendaftaran_anak_asuh`
--
ALTER TABLE `tb_pendaftaran_anak_asuh`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_program_kerja`
--
ALTER TABLE `tb_program_kerja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_slider`
--
ALTER TABLE `tb_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `tb_struktur_organisasi`
--
ALTER TABLE `tb_struktur_organisasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_tujuan`
--
ALTER TABLE `tb_tujuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_visi_misi`
--
ALTER TABLE `tb_visi_misi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_donasi`
--
ALTER TABLE `tbl_donasi`
  ADD CONSTRAINT `tbl_donasi_ibfk_1` FOREIGN KEY (`id_jenis_donasi`) REFERENCES `tbl_jenis_donasi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_donasi_ibfk_2` FOREIGN KEY (`username`) REFERENCES `tbl_donatur` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_media`
--
ALTER TABLE `tbl_media`
  ADD CONSTRAINT `tbl_media_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `tbl_kategorimedia` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `tbl_role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
