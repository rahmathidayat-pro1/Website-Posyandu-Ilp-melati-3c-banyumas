<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Fasilitas extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
           
        }

        public function index()
        {
           
            $data = array(
                'fasilitas' => $this->get_fasilitas()
            );
            view("web.fasilitas",$data);
        }

        public function get_fasilitas()
        {
            $data = $this->db->get("tb_fasilitas")->row();
            return $data;
        }
    }

?>