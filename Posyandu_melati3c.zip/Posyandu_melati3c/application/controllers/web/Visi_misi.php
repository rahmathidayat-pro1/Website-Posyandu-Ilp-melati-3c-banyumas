<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Visi_misi extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
           
        }

        public function index()
        {
           
            $data = array(
                'visi_misi' => $this->get_visi_misi()
            );
            view("web.visi_misi",$data);
        }

        public function get_visi_misi()
        {
            $data = $this->db->get("tb_visi_misi")->row();
            return $data;
        }
    }

?>