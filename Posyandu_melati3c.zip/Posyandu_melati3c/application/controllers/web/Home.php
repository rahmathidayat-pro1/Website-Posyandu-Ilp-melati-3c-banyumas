<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Home extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
            $this->load->library(array('recaptcha','form_validation'));
        }

        public function index()
        {
           
            $data = array(
                'recaptcha_html' => $this->recaptcha->render(),
                'berita'=>$this->get_berita(),
                'galeri'=>$this->get_galeri(),
                'slider'=>$this->get_slider(),
                'detail_panti'=>$this->get_settingprofil()->detail_profil
            );
            view("web.home",$data);
        }

        public function get_berita()
        {
            $this->db->where("id_kategori",1);
            $data = $this->db->get("tbl_media")->result();
            return $data;
        }

        public function get_galeri()
        {
            $this->db->where("id_kategori",2);
            $data = $this->db->get("tbl_media")->result();
            return $data;
        }

        public function get_slider()
        {
            $data = $this->db->get("tb_slider")->result();
            return $data;
        }

        public function get_settingprofil()
        {
            $data = $this->db->get("tbl_settingprofil")->row();
            return $data;
        }

        public function getResponseCaptcha($str)
        {
            $this->load->library('recaptcha');
            $response = $this->recaptcha->verifyResponse($str);
            if ($response['success'])
            {
                return true;
            }
            else
            {
                $this->form_validation->set_message('getResponseCaptcha', '%s is required.' );
                return false;
            }
        }
    }

?>