<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Program_kerja extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
           
        }

        public function index()
        {
           
            $data = array(
                'program_kerja' => $this->get_program_kerja()
            );
            view("web.program_kerja",$data);
        }

        public function get_program_kerja()
        {
            $data = $this->db->get("tb_program_kerja")->row();
            return $data;
        }
    }

?>