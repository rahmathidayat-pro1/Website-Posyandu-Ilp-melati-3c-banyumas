<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Struktur_organisasi extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
           
        }

        public function index()
        {
           
            $data = array(
                'struktur_organisasi' => $this->get_struktur_organisasi()
            );
            view("web.struktur_organisasi",$data);
        }

        public function get_struktur_organisasi()
        {
            $data = $this->db->get("tb_struktur_organisasi")->row();
            return $data;
        }
    }

?>