<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Galeri extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
           
        }

        public function index()
        {
            // Ambil gambar infografis dari folder upload/galeri (PROKER dan foto bulanan)
            $infografis_path = './upload/galeri/';
            $infografis_files = array();
            
            if(is_dir($infografis_path)) {
                $files = array_diff(scandir($infografis_path), array('.', '..'));
                foreach($files as $file) {
                    // Skip folder photo
                    if(is_dir($infografis_path . $file)) {
                        continue;
                    }
                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if(in_array($ext, array('jpg', 'jpeg', 'png', 'gif'))) {
                        $infografis_files[] = $file;
                    }
                }
            }
            
            // Sort agar PROKER urut di awal
            usort($infografis_files, function($a, $b) {
                $isProkerA = strpos($a, 'PROKER') === 0;
                $isProkerB = strpos($b, 'PROKER') === 0;
                
                if($isProkerA && !$isProkerB) return -1;
                if(!$isProkerA && $isProkerB) return 1;
                
                return strcmp($a, $b);
            });
            
            // Ambil foto dari folder upload/galeri/photo
            $photo_path = './upload/galeri/photo/';
            $photo_files = array();
            
            if(is_dir($photo_path)) {
                $files = array_diff(scandir($photo_path), array('.', '..'));
                foreach($files as $file) {
                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if(in_array($ext, array('jpg', 'jpeg', 'png', 'gif'))) {
                        $photo_files[] = $file;
                    }
                }
            }
            
            // Sort foto secara alfabetis
            sort($photo_files);
            
            $data = array(
                'infografis' => $infografis_files,
                'photos' => $photo_files
            );
            view("web.galeri",$data);
        }

    }
    

?>