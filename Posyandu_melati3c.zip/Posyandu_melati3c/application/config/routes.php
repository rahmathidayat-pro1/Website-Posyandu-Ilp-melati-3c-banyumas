<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['setting/role'] = 'admin/setting/role';
$route['setting/role/(:any)'] = 'admin/setting/role/$1';
$route['setting/role/(:any)/(:any)'] = 'admin/setting/role/$1/$2';

$route['setting/user'] = 'admin/setting/user';
$route['setting/user/(:any)'] = 'admin/setting/user/$1';
$route['setting/user/(:any)/(:any)'] = 'admin/setting/user/$1/$2';

$route['master/jenis_donasi'] = 'admin/master/jenis_donasi';
$route['master/jenis_donasi/(:any)'] = 'admin/master/jenis_donasi/$1';
$route['master/jenis_donasi/(:any)/(:any)'] = 'admin/master/jenis_donasi/$1/$2';

$route['master/kategori_media'] = 'admin/master/kategori_media';
$route['master/kategori_media/(:any)'] = 'admin/master/kategori_media/$1';
$route['master/kategori_media/(:any)/(:any)'] = 'admin/master/kategori_media/$1/$2';

$route['media/visi_misi'] = 'admin/media/visi_misi';
$route['media/visi_misi/(:any)'] = 'admin/media/visi_misi/$1';
$route['media/visi_misi/(:any)/(:any)'] = 'admin/media/visi_misi/$1/$2';

$route['media/kontak_kami'] = 'admin/media/kontak_kami';
$route['media/kontak_kami/(:any)'] = 'admin/media/kontak_kami/$1';
$route['media/kontak_kami/(:any)/(:any)'] = 'admin/media/kontak_kami/$1/$2';

$route['media/struktur_organisasi'] = 'admin/media/struktur_organisasi';
$route['media/struktur_organisasi/(:any)'] = 'admin/media/struktur_organisasi/$1';
$route['media/struktur_organisasi/(:any)/(:any)'] = 'admin/media/struktur_organisasi/$1/$2';

$route['media/kepengurusan'] = 'admin/media/kepengurusan';
$route['media/kepengurusan/(:any)'] = 'admin/media/kepengurusan/$1';
$route['media/kepengurusan/(:any)/(:any)'] = 'admin/media/kepengurusan/$1/$2';

$route['media/fasilitas'] = 'admin/media/fasilitas';
$route['media/fasilitas/(:any)'] = 'admin/media/fasilitas/$1';
$route['media/fasilitas/(:any)/(:any)'] = 'admin/media/fasilitas/$1/$2';

$route['media/panduan_donasi'] = 'admin/media/panduan_donasi';
$route['media/panduan_donasi/(:any)'] = 'admin/media/panduan_donasi/$1';
$route['media/panduan_donasi/(:any)/(:any)'] = 'admin/media/panduan_donasi/$1/$2';

$route['media/tujuan'] = 'admin/media/tujuan';
$route['media/tujuan/(:any)'] = 'admin/media/tujuan/$1';
$route['media/tujuan/(:any)/(:any)'] = 'admin/media/tujuan/$1/$2';

$route['media/program_kerja'] = 'admin/media/program_kerja';
$route['media/program_kerja/(:any)'] = 'admin/media/program_kerja/$1';
$route['media/program_kerja/(:any)/(:any)'] = 'admin/media/program_kerja/$1/$2';

$route['media/slider'] = 'admin/media/slider';
$route['media/slider/(:any)'] = 'admin/media/slider/$1';
$route['media/slider/(:any)/(:any)'] = 'admin/media/slider/$1/$2';

$route['media/pendaftaran_anak_asuh'] = 'admin/media/pendaftaran_anak_asuh';
$route['media/pendaftaran_anak_asuh/(:any)'] = 'admin/media/pendaftaran_anak_asuh/$1';
$route['media/pendaftaran_anak_asuh/(:any)/(:any)'] = 'admin/media/pendaftaran_anak_asuh/$1/$2';

$route['media/media'] = 'admin/media/media';
$route['media/media/(:any)'] = 'admin/media/media/$1';
$route['media/media/(:any)/(:any)'] = 'admin/media/media/$1/$2';

$route['media/profil'] = 'admin/media/profil';
$route['media/profil/(:any)'] = 'admin/media/profil/$1';
$route['media/profil/(:any)/(:any)'] = 'admin/media/profil/$1/$2';

$route['data/anak_asuh'] = 'admin/data/anak_asuh';
$route['data/anak_asuh/(:any)'] = 'admin/data/anak_asuh/$1';
$route['data/anak_asuh/(:any)/(:any)'] = 'admin/data/anak_asuh/$1/$2';

$route['data/alumni'] = 'admin/data/alumni';
$route['data/alumni/(:any)'] = 'admin/data/alumni/$1';
$route['data/alumni/(:any)/(:any)'] = 'admin/data/alumni/$1/$2';

$route['data/kunjungan'] = 'admin/data/kunjungan';
$route['data/kunjungan/(:any)'] = 'admin/data/kunjungan/$1';
$route['data/kunjungan/(:any)/(:any)'] = 'admin/data/kunjungan/$1/$2';

$route['transaksi/pengeluaran'] = 'admin/transaksi/pengeluaran';
$route['transaksi/pengeluaran/(:any)'] = 'admin/transaksi/pengeluaran/$1';
$route['transaksi/pengeluaran/(:any)/(:any)'] = 'admin/transaksi/pengeluaran/$1/$2';

$route['transaksi/pemasukan'] = 'admin/transaksi/pemasukan';
$route['transaksi/pemasukan/(:any)'] = 'admin/transaksi/pemasukan/$1';
$route['transaksi/pemasukan/(:any)/(:any)'] = 'admin/transaksi/pemasukan/$1/$2';

$route['laporan/anak_asuh'] = 'ketua_panti/laporan/anak_asuh';
$route['laporan/anak_asuh/(:any)'] = 'ketua_panti/laporan/anak_asuh/$1';
$route['laporan/anak_asuh/(:any)/(:any)'] = 'ketua_panti/laporan/anak_asuh/$1/$2';

$route['laporan/alumni'] = 'ketua_panti/laporan/alumni';
$route['laporan/alumni/(:any)'] = 'ketua_panti/laporan/alumni/$1';
$route['laporan/alumni/(:any)/(:any)'] = 'ketua_panti/laporan/alumni/$1/$2';

$route['laporan/pemasukan'] = 'ketua_panti/laporan/pemasukan';
$route['laporan/pemasukan/(:any)'] = 'ketua_panti/laporan/pemasukan/$1';
$route['laporan/pemasukan/(:any)/(:any)'] = 'ketua_panti/laporan/pemasukan/$1/$2';

$route['laporan/pengeluaran'] = 'ketua_panti/laporan/pengeluaran';
$route['laporan/pengeluaran/(:any)'] = 'ketua_panti/laporan/pengeluaran/$1';
$route['laporan/pengeluaran/(:any)/(:any)'] = 'ketua_panti/laporan/pengeluaran/$1/$2';

$route['laporan/kunjungan'] = 'ketua_panti/laporan/kunjungan';
$route['laporan/kunjungan/(:any)'] = 'ketua_panti/laporan/kunjungan/$1';
$route['laporan/kunjungan/(:any)/(:any)'] = 'ketua_panti/laporan/kunjungan/$1/$2';

$route['home'] = 'web/home';
$route['home/(:any)'] = 'web/home/$1';
$route['home/(:any)/(:any)'] = 'web/home/$1/$2';

$route['visi_misi'] = 'web/visi_misi';
$route['visi_misi/(:any)'] = 'web/visi_misi/$1';
$route['visi_misi/(:any)/(:any)'] = 'web/visi_misi/$1/$2';

$route['struktur_organisasi'] = 'web/struktur_organisasi';
$route['struktur_organisasi/(:any)'] = 'web/struktur_organisasi/$1';
$route['struktur_organisasi/(:any)/(:any)'] = 'web/struktur_organisasi/$1/$2';

$route['fasilitas'] = 'web/fasilitas';
$route['fasilitas/(:any)'] = 'web/fasilitas/$1';
$route['fasilitas/(:any)/(:any)'] = 'web/fasilitas/$1/$2';

$route['tujuan'] = 'web/tujuan';
$route['tujuan/(:any)'] = 'web/tujuan/$1';
$route['tujuan/(:any)/(:any)'] = 'web/tujuan/$1/$2';

$route['program_kerja'] = 'web/program_kerja';
$route['program_kerja/(:any)'] = 'web/program_kerja/$1';
$route['program_kerja/(:any)/(:any)'] = 'web/program_kerja/$1/$2';

$route['kepengurusan'] = 'web/kepengurusan';
$route['kepengurusan/(:any)'] = 'web/kepengurusan/$1';
$route['kepengurusan/(:any)/(:any)'] = 'web/kepengurusan/$1/$2';

$route['pendaftaran_anak_asuh'] = 'web/pendaftaran_anak_asuh';
$route['pendaftaran_anak_asuh/(:any)'] = 'web/pendaftaran_anak_asuh/$1';
$route['pendaftaran_anak_asuh/(:any)/(:any)'] = 'web/pendaftaran_anak_asuh/$1/$2';

$route['alumni'] = 'web/alumni';
$route['alumni/(:any)'] = 'web/alumni/$1';
$route['alumni/(:any)/(:any)'] = 'web/alumni/$1/$2';

$route['donatur'] = 'web/donatur';
$route['donatur/(:any)'] = 'web/donatur/$1';
$route['donatur/(:any)/(:any)'] = 'web/donatur/$1/$2';

$route['user/donasi'] = 'donatur/donasi';
$route['user/donasi/(:any)'] = 'donatur/donasi/$1';
$route['user/donasi/(:any)/(:any)'] = 'donatur/donasi/$1/$2';

$route['user/laporan_donasi'] = 'donatur/laporan_donasi';
$route['user/laporan_donasi/(:any)'] = 'donatur/laporan_donasi/$1';
$route['user/laporan_donasi/(:any)/(:any)'] = 'donatur/laporan_donasi/$1/$2';

$route['berita'] = 'web/berita';
$route['berita/(:any)'] = 'web/berita/$1';
$route['berita/(:any)/(:any)'] = 'web/berita/$1/$2';

$route['galeri'] = 'web/galeri';
$route['galeri/(:any)'] = 'web/galeri/$1';
$route['galeri/(:any)/(:any)'] = 'web/galeri/$1/$2';

$route['anak_asuh'] = 'web/anak_asuh';
$route['anak_asuh/(:any)'] = 'web/anak_asuh/$1';
$route['anak_asuh/(:any)/(:any)'] = 'web/anak_asuh/$1/$2';

$route['alumni'] = 'web/alumni';
$route['alumni/(:any)'] = 'web/alumni/$1';
$route['alumni/(:any)/(:any)'] = 'web/alumni/$1/$2';

$route['kunjungan'] = 'web/kunjungan';
$route['kunjungan/(:any)'] = 'web/kunjungan/$1';
$route['kunjungan/(:any)/(:any)'] = 'web/kunjungan/$1/$2';

$route['panduan_donasi'] = 'web/panduan_donasi';
$route['panduan_donasi/(:any)'] = 'web/panduan_donasi/$1';
$route['panduan_donasi/(:any)/(:any)'] = 'web/panduan_donasi/$1/$2';

