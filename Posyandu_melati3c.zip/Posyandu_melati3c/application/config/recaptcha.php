<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// To use reCAPTCHA, you need to sign up for an API key pair for your site.
// link: http://www.google.com/recaptcha/admin
$config['recaptcha_sitekey'] =  "6Le7gZwcAAAAAGpwvv8R54F-6UGoL_PBvpPXD_h4";

$config['recaptcha_secretkey'] = "6Le7gZwcAAAAAJT9_CHtIIxW_V_NInstfpxwLLJP";

$config['lang'] = "id";

/* End of file recaptcha.php */
/* Location: ./application/config/recaptcha.php */
