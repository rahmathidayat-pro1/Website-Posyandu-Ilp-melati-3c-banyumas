@extends('layout_web.main')
@section('content')
@section('title','Galeri')


<style type="text/css">
    .gallery-item {
        margin-bottom: 30px;
        position: relative;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        background: #f8f9fa;
    }
    
    .gallery-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    
    .gallery-item img {
        width: 100%;
        height: auto;
        display: block;
        border-radius: 10px;
    }
    
    .gallery-item .image-title {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.7) 50%, transparent 100%);
        color: white;
        padding: 20px 15px;
        font-size: 14px;
        font-weight: 500;
        border-radius: 0 0 10px 10px;
    }
    
    .gallery-section {
        padding: 40px 0;
    }
    
    .section-title {
        text-align: center;
        margin-bottom: 40px;
    }
    
    .section-title h2 {
        font-size: 32px;
        font-weight: 700;
        color: #333;
        margin-bottom: 10px;
    }
    
    .section-title .divider {
        width: 60px;
        height: 3px;
        background: #007bff;
        margin: 0 auto;
    }
    
    .nav-tabs {
        border: none;
        justify-content: center;
        margin-bottom: 40px;
    }
    
    .nav-tabs .nav-link {
        border: 2px solid #007bff;
        border-radius: 30px;
        margin: 0 10px;
        padding: 12px 40px;
        color: #007bff;
        font-weight: 600;
        background: white;
        transition: all 0.3s ease;
    }
    
    .nav-tabs .nav-link:hover {
        background: #007bff;
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
    }
    
    .nav-tabs .nav-link.active {
        background: #007bff;
        color: white;
        border-color: #007bff;
        box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
    }
    
    .nav-tabs .nav-link.active:hover {
        background: #0056b3;
        border-color: #0056b3;
    }
    
    /* Style khusus untuk tab foto - tampilan 1:1 */
    .photo-gallery-item {
        margin-bottom: 30px;
        position: relative;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        background: #f8f9fa;
        overflow: hidden;
        padding-bottom: 100%; /* Membuat container 1:1 */
    }
    
    .photo-gallery-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    
    .photo-gallery-item a {
        display: block;
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
    }
    
    .photo-gallery-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        border-radius: 10px;
        transition: transform 0.3s ease;
    }
    
    .photo-gallery-item:hover img {
        transform: scale(1.05);
    }
    
    .photo-gallery-item .image-overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 100%);
        color: white;
        padding: 15px;
        font-size: 13px;
        font-weight: 500;
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .photo-gallery-item:hover .image-overlay {
        opacity: 1;
    }
</style>

<main class="main-content">
<section class="intro-single" style="padding: 3rem 0 1rem !important;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-8">
                <div class="title-single-box">
                    <h1 class="title-single">Galeri</h1>
                </div>
            </div>
            <div class="col-md-12 col-lg-4">
                <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{site_url()}}">Home</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Galeri
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</section>

<section class="gallery-section">
    <div class="container">
        <!-- Tab Navigation -->
        <ul class="nav nav-tabs" id="galleryTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="infografis-tab" data-toggle="tab" href="#infografis" role="tab" aria-controls="infografis" aria-selected="true">
                    Infografis
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="foto-tab" data-toggle="tab" href="#foto" role="tab" aria-controls="foto" aria-selected="false">
                    Foto
                </a>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="galleryTabContent">
            <!-- Tab Infografis -->
            <div class="tab-pane fade show active" id="infografis" role="tabpanel" aria-labelledby="infografis-tab">
                <div class="row">
                    @foreach($infografis as $index => $image)
                    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                        <div class="gallery-item" data-wow-delay="{{ $index * 100 }}ms">
                            <img src="{{ site_url() }}upload/galeri/{{ $image }}" alt="{{ $image }}">
                            <div class="image-title">
                                {{ str_replace(array('.jpg', '.jpeg', '.png', '.gif'), '', $image) }}
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Tab Foto -->
            <div class="tab-pane fade" id="foto" role="tabpanel" aria-labelledby="foto-tab">
                <div class="row">
                    @foreach($photos as $index => $photo)
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mb-4">
                        <div class="photo-gallery-item" data-wow-delay="{{ $index * 100 }}ms">
                            <a href="{{ site_url() }}upload/galeri/photo/{{ $photo }}" data-fancybox="gallery" data-caption="{{ str_replace(array('.jpg', '.jpeg', '.png', '.gif'), '', $photo) }}">
                                <img src="{{ site_url() }}upload/galeri/photo/{{ $photo }}" alt="{{ $photo }}">
                                <div class="image-overlay">
                                    {{ str_replace(array('.jpg', '.jpeg', '.png', '.gif'), '', $photo) }}
                                </div>
                            </a>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
@section("js")
<script>
    // Konfigurasi Fancybox untuk lightbox foto - hindari double initialization
    $(document).ready(function() {
        // Hapus semua event listener yang mungkin sudah terpasang
        $('[data-fancybox="gallery"]').unbind('click');
        $('[data-fancybox="gallery"]').off('click.fb-start');
        
        // Tunggu sebentar untuk memastikan script lain selesai
        setTimeout(function() {
            // Inisialisasi Fancybox hanya sekali dengan konfigurasi
            $('[data-fancybox="gallery"]').fancybox({
                buttons: [
                    "zoom",
                    "share",
                    "slideShow",
                    "fullScreen",
                    "download",
                    "thumbs",
                    "close"
                ],
                loop: true,
                protect: true,
                animationEffect: "fade",
                transitionEffect: "fade",
                animationDuration: 300,
                preventCaptionOverlap: true
            });
        }, 300);
    });
</script>
@endsection