@extends('layout_web.main')
@section('content')
@section('title','Login')

<style type="text/css">
    .card{
        border: 1px solid rgba(0,0,0,.125);
    }
</style>

<main class="main-content">
<section class="intro-single" style="padding: 3rem 0 1rem !important;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-8">
                <div class="title-single-box">
                    <h1 class="title-single"></h1>
                    <!--   <span class="color-text-a">Penilaian</span> -->
                </div>
            </div>
            <div class="col-md-12 col-lg-4">
                <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{site_url()}}">Home</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                        Program Kerja
                        </li>
                    </ol>
                </nav>
            </div>
        </div>

    </div>
</section>
            <section class="welcome type_one">
               <div class="container">
                <div class="row">
                        <div class="col-lg-12">
                            <p>
                               {{$program_kerja->program_kerja}}
                            </p>
                        </div>
                    </div>

                
               </div>
            </section>

         

@endsection
@section("js")

@endsection