@extends('layout_web.main')
@section('content')
@section('title','Home')
<style>
    .sub-title {
        clear: both;
        color: #979797;
        line-height: 13px;
        margin-bottom: 16px;
        font-size: 12px;
    }
</style>
<main class="main-content">
            <!------main-content------>
            <section class="main-slider">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    @php  $no = 0 ; @endphp
                    @foreach($slider as $row)
                        @if($no==0)
                            <div class="carousel-item active">
                                <img class="d-block w-100" src="{{site_url('upload/slider/'.$row->slider)}}" alt="First slide">
                            </div>
                        @else
                            <div class="carousel-item">
                                <img class="d-block w-100" src="{{site_url('upload/slider/'.$row->slider)}}">
                            </div>
                        @endif
                        @php $no++; @endphp
                    @endforeach
                  
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            </section>

            <!------main-slider------>
            <section class="welcome type_one">
               <div class="container">
                  <div class="slide one">
                     <div class="container text-left">
                        <div class="row">
                        <div class="col-md-12 col-lg-8">
                           <div class="title-single-box">
                             
                           </div>
                        </div>
                  
                        </div>
                     
       <div class="row">
           <div class="col-lg-12">
               <div class="card mx-auto mb-5">
                   <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-8">
                                <h3 style="color: #0020afff; font-weight: 800;">
    PROFIL SINGKAT POSYANDU ILP MELATI 3C BANYUMAS
</h3>
 <BR>
                                <div class="title-single-box">
                                  
<div class="title-single-box">
    <p>
        Posyandu ILP Melati 3C merupakan pusat pelayanan kesehatan masyarakat di wilayah Banyumas
        di jalan Warga Batik Raya , Purwokerto Lor , yang bertempat di rumah Dinas lurah 
        yang berfokus pada upaya promotif dan preventif bagi seluruh kelompok usia. Posyandu ini 
        dikelola oleh kader terlatih bekerja sama dengan tenaga kesehatan Puskesmas, dengan tujuan 
        meningkatkan derajat kesehatan masyarakat melalui kegiatan rutin dan terintegrasi.
    </p> <br>

    <h4> Pelayanan Balita Usia 0–5 Tahun</h4>
    <ul>
        <li>> Penimbangan dan pengukuran tinggi badan rutin</li>
        <li>> Pencatatan perkembangan balita</li>
        <li>> Pemberian imunisasi sesuai jadwal</li>
        <li>> Pemantauan status gizi</li>
        <li>> Edukasi kesehatan kepada orang tua</li>
        <li>> Pemberian Makanan Tambahan (PMT)</li>
    </ul> <br>

    <h4>Posbindu Usia 15–59 Tahun</h4>
    <ul>
        <li>> Pemeriksaan tekanan darah</li>
        <li>> Pemeriksaan gula darah (jika tersedia)</li>
        <li>> Pengukuran berat badan, tinggi badan, dan lingkar perut</li>
        <li>> Konseling gaya hidup sehat</li>
        <li>> Edukasi pencegahan penyakit tidak menular</li>
        <li>> Pemantauan faktor risiko PTM</li>
    </ul> <br>

    <h4>Pelayanan Lansia Usia 60 Tahun ke Atas</h4>
    <ul>
        <li>> Pemeriksaan kesehatan rutin</li>
        <li>> Pemantauan tekanan darah dan kondisi umum</li>
        <li>> Senam lansia</li>
        <li>> Edukasi pola hidup sehat</li>
        <li>> Pendampingan kesehatan mental dan sosial</li>
        <li>> Pemantauan penyakit kronis</li>
    </ul> <br>

    <h5>Komitmen Kami</h5>
    <p>
        Posyandu ILP Melati 3C berkomitmen memberikan layanan kesehatan yang mudah diakses, ramah, 
        dan bermanfaat bagi seluruh warga. Melalui kegiatan posyandu balita, posbindu usia 
        produktif, dan layanan lansia, kami terus mendukung terwujudnya masyarakat yang lebih 
        sehat dan sejahtera.
    </p>
</div><BR><BR><BR><BR>
</p>
                                </div>
                            </div>
                        </div>
                        <hr>
                       <div class="card-title">
                           <h3 style="color: #0020afff; font-weight: 800;">

                       <div class="card-title">
                                                      <h3 style="color: #0020afff; font-weight: 800;">
    JADWAL KEGIATAN 
        <p><br>
Pelayanan Rutin Setiap Tanggal 1 Setiap Bulan <br>
Pukul 08.00 – 11.00 WIB <br>
Tempat: Balai Posyandu ILP Melati 3 C Kantor dinas lurah purwokerto lor<br>
Jalan Warga Batik Raya
    </p> <br>
                           <hr>
                       </div>

                       <div class="row">
                         
                       </div>    

                     </div>
               </div>
           </div>
           <div class="col-lg-4">

           </div>
       </div>
                     </div>
                  </div>
                  
               </div>
            </section>
            <!------main-slider------>

            
            
            
            
            
            
         
           
         </main>

@endsection
@section("js")
<script>
   $("#nik").attr("maxlength", 16);
   $("#nik").attr("minlength", 16);
</script>
@endsection