<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <meta name="title" content="Corona">
      <meta property="fb:app_id" content="312" />
      <meta property="og:type" content="Corona" />
      <meta property="og:url" content="http://steelthemes.com/demo/Elango/Corona-final" />
      <meta property="og:title" content="Corona">
      <meta property="og:image" content="http://steelthemes.com/demo/Elango/Corona-final/assets/image/fbimg-210x210.jpg">
      <meta property="og:description" content="Corona is html 5 Template">
      <meta name="full-screen" content="yes">
      <meta name="theme-color" content="#269bef">
      <!-- Responsive -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
      <title>Posyandu Ilp Melati 3C</title>
      <link rel="stylesheet" type="text/css" href="{{WEB_ASSETS}}css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="{{WEB_ASSETS}}css/style.css">
      <link rel="stylesheet" type="text/css" href="{{WEB_ASSETS}}fonts/font/flaticon.css">
      <link href="{{WEB_ASSETS}}css/dataTables/datatables.min.css" rel="stylesheet">
      <link href="{{WEB_ASSETS}}css/dataTables/responsive.dataTables.min.css" rel="stylesheet">
      <link href="{{WEB_ASSETS}}css/sweetalert/sweetalert.css" rel="stylesheet">
      <link href="{{WEB_ASSETS}}css/summernote/summernote-bs4.css" rel="stylesheet">
      <!---------favicon--------------->
<link rel="icon" type="image/png" href="<?= base_url('web-assets/image/favicon.png'); ?>">

      <meta name="msapplication-TileColor" content="#ffffff">
      <meta name="msapplication-TileImage" content="{{WEB_ASSETS}}image/ms-icon-144x144.png">
      <meta name="theme-color" content="#ffffff">
      <!---------favicon--------------->
   </head>
   <body class="home_page_one">
      <div class="page_wapper">
          <!--Start Preloader-->
          <div class="preloader">
            <div class="preloader_box">
               <div class="loader">
                  <div class="circle item0"></div>
                  <div class="circle item1"></div>
                  <div class="circle item2"></div>
               </div>
            </div>
         </div>
         
         
         <!--End Preloader -->
         <!--Header-->
         
         <header class="header_v2">
         <section class="header_top">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-8">
                        <div class="row">
                           <div class="col-lg-3 col-md-3">
                              <div class="heading">
                                 <h2>Selamat Datang</h2>
                              </div>
                           </div>
                           <div class="col-lg-9 col-md-9">
                              <div class="news_inner">
                                 <div class="">
                                    <div class="mid-text">
                                       <p><a href="https://maps.app.goo.gl/xMZmaPpKD6eiAMzY7" target="_blank" style="color: white;" class="fa fa-map-marker"></a></p>
                                    </div>
                                   
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="text_right">
                           <div class="social_media_icon">
                              <ul class="clearfix">
                                 <li>
                                    <a href="" class="has-tooltip">
                                       <span class="fa fa-facebook"></span>
                                       <div class="c-tooltip">
                                          <div class="tooltip-inner">Facebook</div>
                                       </div>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="" class="has-tooltip">
                                       <span class="fa fa-twitter"></span>
                                       <div class="c-tooltip">
                                          <div class="tooltip-inner">Twitter</div>
                                       </div>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="" class="has-tooltip">
                                       <span class="fa fa-instagram"></span>
                                       <div class="c-tooltip">
                                          <div class="tooltip-inner">Instagram</div>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
       
            <section class="navbar_outer">
               <div class="navbar navbar-expand-lg  bsnav bsnav-sticky bsnav-sticky-slide">
                  <div class="container">
<img src="{{site_url()}}upload/logo/logo.png"
     width="85"
     class="img-fluid"
     alt="Logo"
     style="margin: 20px 10px; display: inline-block;">
<span style="font-weight: bold; margin-left: 20px; font-size: 20px; display: inline-block; vertical-align: middle;">
    POSYANDU ILP MELATI 3C BANYUMAS
</span>

                     <button class="navbar-toggler toggler-spring"><span class="navbar-toggler-icon"></span></button>
                     <div class="collapse navbar-collapse scroll-nav">
                        <ul class="navbar-nav navbar-mobile navbar_left  ml-auto" id="nav">
                        
                           <li class="nav-item nav_item">
                              <a class="nav-link link_hd" href="{{site_url()}}home">  BERANDA  </a>
                           </li>
                           <li class="nav-item dropdown">
                              <a class="nav-link link_hd" data-toggle="dropdown" href="#">PROFIL</a>
                              <div class="dropdown-menu">
                                 <a class="dropdown-item" href="{{site_url()}}visi_misi">VISI & MISI</a>
                                 <a class="dropdown-item" href="{{site_url()}}struktur_organisasi">STRUKTUR ORGANISASI</a>
                                 <a class="dropdown-item" href="{{site_url()}}fasilitas">FASILITAS</a>

                                 <a class="dropdown-item" href="{{site_url()}}program_kerja">PROGRAM KERJA</a>

                              </div>
                           </li>

                           <li class="nav-item dropdown">
                              <a class="nav-link link_hd" data-toggle="dropdown" href="#">MEDIA</a>
                              <div class="dropdown-menu">

                                 <a class="dropdown-item" href="{{site_url()}}galeri">GALERI</a>
                              </div>
                           </li>

                           <li class="nav-item dropdown">
                              <a class="nav-link link_hd" data-toggle="dropdown" href="#">DATA</a>
                              <div class="dropdown-menu">
                                 <a class="dropdown-item" href="<?= site_url('balita'); ?>"
>BALITA 0-5 TAHUN</a>
                                 <a class="dropdown-item" href="<?= site_url('posbindu'); ?>"
      >POSBINDU 15-59 TAHUN</a>
                                 <a class="dropdown-item" href="<?= site_url('lansia'); ?>">LANSIA 60 TAHUN LEBIH</a>
                              </div>
                           </li>


                        
                        </ul>
                        
                     </div>
                  </div
               </div>
            </section>
         </header>

         @yield("content")
         <section class="footer type_two">
               <div class="footer_layer" style="background-image: url({{WEB_ASSETS}}image/resources/footer-bg1.png);"></div>
               <div class="container">
               <div class="row">
                     <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="footer_widgets tp_two">
                           <h3 class="widgets_title">Kontak</h3>
                           <div class="inner_widgets">
                              <div class="text_box">
                                 <span class="fa fa-map-marker"></span>
                                 <p>Alamat : Jln. Warga Batik Raya , Purwokerto Lor, Rumah Dinas Lurah Banyumas</p>
               </div>
                              <div class="text_box">
                                 <span class="fa fa-phone"></span>
                                 <p>Telepon : 0815 7956 313</p>
                              </div>
                              <div class="text_box">
                                 <span class="fa fa-phone"></span>
                                 <p>Fax :</p>
                              </div>
                              <div class="text_box">
                                 <span class="fa fa-envelope"></span>
                                 <p>Email : iinaenah323@gmail.com<p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footer_last type_two">
                     <div class="row">
                        <div class="col-lg-12 text-center">
                           <p>Copyright © 2025 Posyandu Ilp Melati 3C. Support by Mohammad Rachmat Hidayat - All Right Reserved</p>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-------------main-centent-end--------------->
         </main>
         </div>
      <!--Scroll to top-->
      <a href="#" id="scroll" class="default-bg" style="display: inline;"><span class="fa fa-angle-up"></span></a>
      <!---------mbile-navbar----->
      <div class="bsnav-mobile">
         <div class="bsnav-mobile-overlay"></div>
         <div class="navbar">
            <button class="navbar-toggler toggler-spring mobile-toggler"><span class="fa fa-close"></span></button>
         </div>
      </div>
      <!---------mbile-navbar----->
      <!-- /.side-menu__block -->
      <div class="side-menu__block">
         <div class="side-menu__block-overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
         </div>
         <!-- /.side-menu__block-overlay -->
         <div class="side-menu__block-inner">
            <div class="row">
               <div class="col-lg-12">
                  <div class="logo_site">
                     <a href="index.html"><img src="{{WEB_ASSETS}}image/home-1-logo.png" alt="logo" /></a>
                  </div>
                  <div class="side-menu__block-contact">
                     <h2>Quick Online Consultancy Only on Few Minutes</h2>
                     <div class="form_outer">
                        <form>
                           <div class="from_group">
                              <input type="text" name="name" placeholder="Name" />
                           </div>
                           <div class="from_group">
                              <input type="email" name="email" placeholder="Email" />
                           </div>
                           <div class="from_group">
                              <input type="text" name="phone" placeholder="Phone" />
                           </div>
                           <div class="from_group">
                              <textarea rows="4" placeholder="Share Your Thoughts"></textarea>
                           </div>
                           <div class="from_group">
                              <button  class="theme_btn tp_two" type="submit">Contact Us</button>
                           </div>
                        </form>
                     </div>
                  </div>
                  <!-- /.side-menu__block-contact -->
                  <div class="side-menu__block-contact">
                     <h3 class="side-menu__block__title">Contact Us</h3>
                     <!-- /.side-menu__block__title -->
                     <ul class="side-menu__block-contact__list">
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-map-marker"></i> Rock St 12, Newyork City, USA
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-phone"></i>
                           <a href="tel:526-236-895-4732">(526) 236-895-4732</a>
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-envelope"></i>
                           <a href="mailto:example@mail.com">example@mail.com</a>
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                        <li class="side-menu__block-contact__list-item">
                           <i class="fa fa-clock-o"></i> Week Days: 09.00 to 18.00 Sunday: Closed
                        </li>
                        <!-- /.side-menu__block-contact__list-item -->
                     </ul>
                     <!-- /.side-menu__block-contact__list -->
                  </div>
                  <!-- /.side-menu__block-contact -->
                  <p class="side-menu__block__text site-footer__copy-text"><a href="#">corano</a> <i class="fa fa-copyright"></i> 2020 All Right Reserved</p>
               </div>
            </div>
            <!-- /.side-menu__block-inner -->
         </div>
      </div>
      <!-- /.side-menu__block -->
      <!-- /.search-popup -->
      <div class="search-popup">
         <div class="search-popup__overlay custom-cursor__overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
         </div>
         <!-- /.search-popup__overlay -->
         <div class="search-popup__inner">
            <form action="#" class="search-popup__form">
               <input type="text" name="search" placeholder="Type here to Search....">
               <button type="submit"><i class="flaticon-magnifying-glass"></i></button>
            </form>
         </div>
         <!-- /.search-popup__inner -->
      </div>
      <!-- /.search-popup -->
      <!-----------------------------------script-------------------------------------->
      <script src="{{WEB_ASSETS}}js/jquery.js"></script>
      <script src="{{WEB_ASSETS}}js/popper.min.js"></script>
      <script src="{{WEB_ASSETS}}js/bootstrap.min.js"></script>
      <script src="{{WEB_ASSETS}}js/bsnav.min.js"></script>
      <script src="{{WEB_ASSETS}}js/jquery-ui.js"></script>

      <script src="{{WEB_ASSETS}}js/owl.js"></script>
      <script src="{{WEB_ASSETS}}js/wow.js"></script>
      <script src="{{WEB_ASSETS}}js/jquery.fancybox.js"></script>
      <script src="{{WEB_ASSETS}}js/TweenMax.min.js"></script>
      <script src="{{WEB_ASSETS}}js/validator.min.js"></script>
      <script src="{{WEB_ASSETS}}js/appear.js"></script>
      <script src="{{WEB_ASSETS}}js/moment.js"></script>
      <script src="{{WEB_ASSETS}}js/jquery.flexslider-min.js"></script>
      <script src="{{WEB_ASSETS}}js/pagenav.js"></script>
      <script src="{{WEB_ASSETS}}js/custom.js"></script>
      <script src="{{WEB_ASSETS}}js/dataTables/datatables.min.js"></script>
      <script src="{{WEB_ASSETS}}js/dataTables/dataTables.bootstrap4.min.js"></script>
      <script src="{{WEB_ASSETS}}js/dataTables/dataTables.responsive.min.js"></script>
      <script src="{{WEB_ASSETS}}js/sweetalert/sweetalert.min.js"></script>
      <script src="{{WEB_ASSETS}}js/summernote/summernote-bs4.js"></script>

      @yield("js")
   </body>
</html>