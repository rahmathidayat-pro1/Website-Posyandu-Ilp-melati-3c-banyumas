<?php
// posbindu.php - Halaman narasi Posbindu 15–59 Tahun dengan efek animasi
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Posbindu</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #d7e3ff, #eef2ff);
        }
        .wrapper {
            width: 90%;
            max-width: 900px;
            margin: 60px auto;
        }
        .card {
            background: rgba(255, 255, 255, 0.88);
            backdrop-filter: blur(12px);
            padding: 30px;
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.14);
            animation: fadeIn 1s ease;
            border-left: 6px solid #3057c9;
            transition: 0.3s;
        }
        .card:hover {
            box-shadow: 0 18px 40px rgba(45,91,204,0.45);
            transform: translateY(-5px);
        }
        h2 {
            text-align: center;
            color: #274bb0;
            font-size: 28px;
            margin-bottom: 18px;
        }
        p {
            font-size: 17px;
            line-height: 1.8;
            text-align: justify;
            color: #333;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="card">
        <h2>Data Peserta Posbindu Usia 15–59 Tahun</h2>

        <p>
            Posbindu Posyandu ILP Melati 3C Banyumas saat ini melayani
            <strong>67 warga usia 15–59 tahun</strong> yang terdiri dari
            <strong>63 perempuan</strong> dan <strong>4 laki-laki</strong>. Kegiatan Posbindu berfokus pada upaya
            pencegahan penyakit tidak menular dengan melakukan pemantauan kesehatan secara rutin.
        </p>

        <p>
            Pemeriksaan meliputi pengukuran tekanan darah, berat badan, lingkar perut, indeks massa tubuh (IMT),
            serta konseling pola hidup sehat. Melalui kegiatan ini, masyarakat usia produktif dapat mengetahui
            kondisi kesehatannya secara berkala serta memahami cara mencegah risiko penyakit seperti hipertensi,
            diabetes, obesitas, dan gangguan metabolik.
        </p>

        <p>
            Dengan adanya layanan Posbindu, masyarakat diharapkan tetap aktif, sehat, dan produktif sehingga mampu
            menjaga kualitas hidup serta mengurangi risiko penyakit secara mandiri dan berkelanjutan.
        </p>
    </div>
</div>

</body>
</html>
