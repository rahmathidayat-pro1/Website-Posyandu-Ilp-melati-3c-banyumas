<?php
// balita.php - Halaman narasi Balita 0-5 Tahun
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Balita 0-5 Tahun</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #d7e3ff, #f7f9ff);
        }
        .wrapper {
            width: 90%;
            max-width: 900px;
            margin: 60px auto;
        }
        .card {
            background: rgba(255, 255, 255, 0.88);
            backdrop-filter: blur(12px);
            padding: 30px;
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            animation: fadeIn 1s ease;
            border-left: 6px solid #2d5bcc;
        }
        h2 {
            text-align: center;
            color: #244aa8;
            font-size: 28px;
            margin-bottom: 15px;
        }
        p {
            font-size: 17px;
            line-height: 1.8;
            text-align: justify;
            color: #333;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .glow {
            transition: 0.3s;
        }
        .glow:hover {
            box-shadow: 0 18px 40px rgba(45,91,204,0.45);
            transform: translateY(-5px);
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="card glow">
        <h2>Data Balita Usia 0–5 Tahun</h2>
        <p>
            Posyandu ILP Melati 3C Banyumas saat ini melayani
            <strong>34 balita usia 0–5 tahun</strong> yang terdiri dari
            <strong>20 balita perempuan</strong> dan <strong>14 balita laki-laki</strong>. Seluruh balita secara rutin
            mengikuti kegiatan pemantauan pertumbuhan, penimbangan berat badan, pengukuran tinggi badan, serta
            pemeriksaan kesehatan dasar untuk memastikan tumbuh kembang mereka tetap optimal.
        </p>
        <p>
            Pemeriksaan tersebut menjadi langkah penting dalam pencegahan stunting, pemantauan perkembangan, serta
            deteksi dini terhadap potensi gangguan kesehatan balita. Dengan pemantauan yang konsisten, orang tua dapat
            memperoleh informasi lengkap mengenai kondisi kesehatan anak serta langkah-langkah yang perlu dilakukan
            untuk mendukung pertumbuhan ideal.
        </p>
        <p>
            Posyandu Balita ILP Melati 3C berkomitmen memberikan pelayanan terbaik bagi setiap anak, sehingga mereka
            dapat tumbuh sehat, kuat, dan berkembang secara maksimal sesuai usianya.
        </p>
    </div>
</div>

</body>
</html>