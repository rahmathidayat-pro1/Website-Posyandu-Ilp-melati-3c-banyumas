<?php
// lansia.php - Halaman narasi Posyandu Lansia
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Posyandu Lansia</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #cdd9ff, #f5f7ff);
        }
        .wrapper {
            width: 90%;
            max-width: 900px;
            margin: 60px auto;
        }
        .card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            animation: fadeIn 1s ease;
            border-left: 6px solid #3b5cc5;
        }
        h2 {
            text-align: center;
            color: #2c4ca5;
            font-size: 28px;
            margin-bottom: 15px;
        }
        p {
            font-size: 17px;
            line-height: 1.8;
            text-align: justify;
            color: #333;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .glow {
            transition: 0.3s;
        }
        .glow:hover {
            box-shadow: 0 15px 35px rgba(59,92,197,0.45);
            transform: translateY(-4px);
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="card glow">
        <h2>Data Posyandu Lansia</h2>
        <p>
            Posyandu Lansia ILP Melati 3C Banyumas saat ini melayani
            <strong>57 peserta lanjut usia</strong> yang terdiri dari
            <strong>53 perempuan</strong> dan <strong>4 laki-laki</strong>. Program ini bertujuan untuk meningkatkan
            kesehatan dan kesejahteraan lansia melalui kegiatan promotif, preventif, serta pemantauan kondisi
            kesehatan secara berkala.
        </p>
        <p>
            Pemeriksaan rutin meliputi pengukuran tekanan darah, berat badan, lingkar perut, dan indeks massa tubuh
            (IMT). Selain itu, dilakukan pula skrining risiko penyakit degeneratif seperti hipertensi, diabetes,
            kolesterol tinggi, serta gangguan sendi yang sering dialami oleh kelompok usia lanjut.
        </p>
        <p>
            Lansia juga mendapatkan edukasi penting mengenai pola makan sehat, aktivitas fisik ringan, pencegahan
            jatuh, serta cara menjaga kesehatan mental dan emosional. Program senam lansia menjadi salah satu kegiatan
            favorit yang tidak hanya menjaga kebugaran, tetapi juga meningkatkan interaksi sosial antar peserta.
        </p>
        <p>
            Melalui keberadaan Posyandu Lansia, diharapkan para peserta dapat menikmati masa tua dengan tetap sehat,
            mandiri, dan produktif, serta mampu mencegah berbagai penyakit kronis melalui gaya hidup yang lebih baik.
        </p>
    </div>
</div>

</body>
</html>